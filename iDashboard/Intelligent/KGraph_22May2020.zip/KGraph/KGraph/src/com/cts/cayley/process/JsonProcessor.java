package com.cts.cayley.process;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import com.cts.cayley.VO.AttributeVO;

import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.cts.cayley.DAO.RDBConnector;
import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.RelationsVO;
import com.cts.cayley.VO.TypeVO;

public class JsonProcessor extends RDBConnector {
                /**
                * 
                 * @param jsonPath                       path of .json file
                * @param topLayerKeys             keys in the .json file
                * @param relationKeys                second layer keys in the .json file
                * @return                                                          returns list of VO containing json values
                * @throws JSONException
                * @throws IOException
                */
                public List<GraphDBVO> parseJson(String jsonString, List<String> topLayerKeys) throws JSONException, IOException {
                                
                                JSONArray jsonArray = null;
                                JSONArray tempnew = new JSONArray();
                                JSONObject tempObj = null;
                           //     JSONArray tempArray = null;
                                //FileIO file = new FileIO();
                                jsonArray = new JSONArray(jsonString);//file.readFile(jsonPath));
                                List<GraphDBVO> configsList = new ArrayList<GraphDBVO>();
                                
                            
                                //List<RelationsVO> relationsList = null;
                                JSONObject jsonObj = null;
                                GraphDBVO configs = null;
                          //      AttributeVO assist = null;
                                
                                //RelationsVO relations = null;
                           //     TypeVO types =null;
                                HashMap<String, ArrayList<String>> type = null;
                                // List<String> typeval =new ArrayList<String>();
                                String keyString;

                                if (jsonArray != null)  {
                                                for (int i = 0; i < jsonArray.length(); i++)  {   
                                                	
                                                                configs = new GraphDBVO();
                                                          //      assist= new AttributeVO();
                                                                jsonObj = jsonArray.getJSONObject(i);
                                                                
                                                                //configs.setDbName(jsonObj.getString(topLayerKeys.get(0)));
                                                                configs.setUsername(jsonObj.getString(topLayerKeys.get(1)));
                                                                configs.setPassword(jsonObj.getString(topLayerKeys.get(2)));
                                                               // configs.setQuery(jsonObj.getString(topLayerKeys.get(3)));
                                                            
                                                             //   assist.setDbkey(jsonObj.getString(topLayerKeys.get(7)));
                                                                tempObj = jsonObj.getJSONObject(topLayerKeys.get(6));          
                                                
                                                              //  System.out.println("tempObj"+tempObj);
                                                                
                                                                Iterator<String> keys = tempObj.keys();
                                                                type= new HashMap<String, ArrayList<String>>();
                                                                	while(keys.hasNext()) {
                                                	  
                                                                	keyString = (String)keys.next();
                                                                	//  System.out.println("keyString"+keyString);
                                                                	tempnew= tempObj.getJSONArray(keyString);
                                                                	// System.out.println("tempnew"+tempnew);
                                                                	ArrayList<String> templist = new ArrayList<String>();
                                                                		for(int j=0;j<tempnew.length();j++) {
                                                                		templist.add(tempnew.get(j).toString());
                                                                		}
                                                                	//   System.out.println(tempnew.get(0).toString()+" is a ");
                                                                	type.put(keyString, templist);
                                                                	//    System.out.println("type&&&&&&&&&&&"+type);
                                                    }                                                    
                                                 
                                                    configs.setDbType(jsonObj.getString(topLayerKeys.get(4)));
                                                    configs.setHost(jsonObj.getString(topLayerKeys.get(5)));
                                                    configsList.add(configs);   
                                                                
                                                                //tempArray = jsonObj.getJSONArray(topLayerKeys.get(5));
                                                                /*if(tempArray!=null)
                                                                {
                                                                                relationsList = new ArrayList<RelationsVO>();
                                                                                //relationsList.clear();                                                                    
                                                                                for(int j=0;j<tempArray.length();j++)
                                                                                {
                                                                                                relations = new RelationsVO();                                                                  
                                                                                                tempObj = tempArray.getJSONObject(j);
                                                                                                System.out.println("tempObj****"+tempObj);
                                                                                                relations.setValue1(tempObj.getString(relationKeys.get(0)));
                                                                                                relations.setRelationship(tempObj.getString(relationKeys.get(1)));
                                                                                                relations.setValue2(tempObj.getString(relationKeys.get(2)));
                                                                                                relations.setValue1_type(tempObj.getString(relationKeys.get(3)));
                                                                                                relations.setValue2_type(tempObj.getString(relationKeys.get(4)));
                                                                                                relationsList.add(relations);
                                                                                }
                                                                                configs.setRelations(relationsList);
                                                                                
                                                                                
                                                                }*/
                                                       			
                                            }
                             }
                           
                             return configsList;
                }
                
                /** 
                 * 
                 * @param jsonPath       path of the .json file
                * @return                                          returns the contents in the .json file in the form of string
                * @throws IOException
                */
                /*private static String loadJson(String jsonPath) throws IOException
                {
                                StringBuilder stringBuilder = new StringBuilder();
                                InputStream stream = new FileInputStream(jsonPath);
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));

                                String line;
        while ((line = bufferedReader.readLine()) != null) {
                           stringBuilder.append(line);
                   } 

                   bufferedReader.close();
                   return stringBuilder.toString();
                                
                }*/
}
