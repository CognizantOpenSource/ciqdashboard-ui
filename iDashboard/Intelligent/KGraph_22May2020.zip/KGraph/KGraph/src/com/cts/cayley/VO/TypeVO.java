package com.cts.cayley.VO;

import java.util.List;

public class TypeVO {
	
	
	private String name;
	private int id;
	private List<RelationsVO> subVO;
	
	public List<RelationsVO> getSubVO() {
		return subVO;
	}
	public void setSubVO(List<RelationsVO> subVO) {
		this.subVO = subVO;
	}
	public int getId() {
		return id;
	}
	public void setId(int i) {
		this.id = i;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}