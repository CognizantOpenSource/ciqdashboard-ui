package com.cts.cayley.VO;

import java.util.ArrayList;
import java.util.List;


public class AttributeVO {
	
	private String dbColumnName;
	private String relation;
	private String type;
	private String isGroupable;
	private String nlpFeed;
	private String key;
	private String dataType;
	private boolean extractKeyword;
	private boolean tokenize;
	public String alias;
	private List<String> primaryKey;
	private List<String> variableAlias;
	private int modified;

	
	public String getDbColumnName() {
		return dbColumnName;
	}
	public void setDbColumnName(String dbColumnName) {
		this.dbColumnName = dbColumnName;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIsGroupable() {
		return isGroupable;
	}
	public void setIsGroupable(String isGroupable) {
		this.isGroupable = isGroupable;
	}
	public String getNlpFeed() {
		return nlpFeed;
	}
	public void setNlpFeed(String nlpFeed) {
		this.nlpFeed = nlpFeed;
	}
	public boolean isExtractKeyword() {
		return extractKeyword;
	}
	public void setExtractKeyword(boolean extractKeyword) {
		this.extractKeyword = extractKeyword;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public List<String> getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(List<String> primaryKey) {
		this.primaryKey = primaryKey;
	}
	public boolean isTokenize() {
		return tokenize;
	}
	public void setTokenize(boolean tokenize) {
		this.tokenize = tokenize;
	}
	public List<String> getVariableAlias() {
		return variableAlias;
	}
	public void setVariableAlias(List<String> variableAlias) {
		this.variableAlias = variableAlias;
	}
	public int getModified() {
		return modified;
	}

	public void setModified(int modified) {
		this.modified = modified;
	}

	
	
	
	
	
}
