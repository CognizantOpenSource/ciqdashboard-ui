package com.cts.cayley.process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;

import com.cts.cayley.util.Constants;
import com.cts.cayley.util.PropertyManager;

public class Nodedeletetion {

	static HttpClient httpClient = HttpClients.createDefault();
	
	public void executeQuery(String params) throws ClientProtocolException, IOException
	{
		
    		HttpPost req = new HttpPost(PropertyManager.getProperty("dbservice", Constants.CONFIGFILE) +
                          		PropertyManager.getProperty("dbselect", Constants.CONFIGFILE));
            req.addHeader("content-type", "text/javascript");
            req.setEntity(new StringEntity(params));  // input given for selecting node
            HttpResponse resp = null;
            try{
          		resp = httpClient.execute(req);
            } catch (IOException e) {
                e.printStackTrace();
            }
        
            String output="";  
            if(resp.getStatusLine().getStatusCode()==200)  {
          	BufferedReader br = null;
          	br = new BufferedReader(new InputStreamReader((resp.getEntity().getContent()))); // input passing for deleting node
          	//System.out.println("resp content::::"+resp.getEntity().getContent());
          	String temp="";
          	while ((temp = br.readLine()) != null) {
          		 output+=temp;
          		
          		}
          	}
            System.out.println("output::::"+output);
            
          	req = new HttpPost(PropertyManager.getProperty("dbservice", Constants.CONFIGFILE) +
                          				PropertyManager.getProperty("dbdelete", Constants.CONFIGFILE));
          	req.addHeader("content-type", "text/javascript");
          	StringEntity delnode = null;
          	//System.out.println("output data::::::::"+output);
          	delnode = new StringEntity(output.substring(15,output.length()-3),"UTF-8");
          //	System.out.println("delnode:::::::"+output.substring(15,output.length()-3));
          	req.setEntity(delnode);
          	HttpResponse del = null;
          	del = httpClient.execute(req);
          	
            String output2=""; 
            if(resp.getStatusLine().getStatusCode()==200)  {
          	BufferedReader br = null;
          	br = new BufferedReader(new InputStreamReader((del.getEntity().getContent())));
          	//System.out.println("del content:::::"+del.getEntity().getContent());
          	String temp="";
          	while ((temp = br.readLine()) != null) {
          		 output2+=temp;
          		
          		}
          	
          	}
           //System.out.println("output::::"+output2);
          	
            req.releaseConnection();
			
    }
	}

