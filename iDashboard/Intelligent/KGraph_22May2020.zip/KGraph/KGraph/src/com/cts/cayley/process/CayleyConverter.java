package com.cts.cayley.process;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.cts.cayley.NQ.DAO.*;
//import com.cts.cayley.DAO.Mongo;
import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphObjVO;
import com.cts.cayley.VO.GraphTableVO;
import com.cts.cayley.VO.KGraphVO;
import com.cts.cayley.VO.TypeVO;
import com.cts.cayley.util.Constants;
import com.cts.cayley.util.PropertyManager;
import com.fasterxml.jackson.databind.ObjectMapper;


public class CayleyConverter extends TimerTask{

	public static int varCount=0;
	private static final String BATCH_FILE = "newBatch.bat";
	//private static final String INPUTFILE = "mongo_test.json";
	//private static final String OUTPUTFILE = "out1.nq";

	private static boolean isRunning=false;
	
	//@SuppressWarnings("null")
	public static void main(String[] args){
		Timer timer = null;
		if (timer == null) {

			// System.out.println("starting timer.................");
			CayleyConverter task = new CayleyConverter();
			timer = new Timer();
			
			timer.schedule(task, Calendar.getInstance().getTime(), 1000 * 1 * 30);
		}
	}
    
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			populateCayleyDB();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		executeBatchFile();
		
		
	
	}
	
	private static void executeBatchFile()
	{
		if(!isRunning)
		{
			isRunning =true;
			//timeKeeper = "Start time : "+new Date().toString();
		
			//String batchFile = PropertyManager.getProperty("batchfile", Constants.CONFIGFILE);
			String cayleyDBDir = PropertyManager.getProperty("cayleydbdir", Constants.CONFIGFILE);
			String cayleyConfigFile = PropertyManager.getProperty("cayleyconfigfile", Constants.CONFIGFILE);
			String outputNQFile = PropertyManager.getProperty("outputnqfile", Constants.CONFIGFILE);
			
			String command = BATCH_FILE + " " + cayleyDBDir + " " + cayleyConfigFile + " " + outputNQFile;
			String[] commandFormat = {"cmd.exe", "/C", "Start", command};
	        try {
				Process p =  Runtime.getRuntime().exec(commandFormat);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			isRunning = false;
			
		}
		
	}
	
	private static void populateCayleyDB() throws IOException
	{
		Date dNow = new Date();
	    SimpleDateFormat ft =  new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
	    System.out.println("Start Time: " + ft.format(dNow));
		FileIO file = new FileIO();
		String outputNQFile = PropertyManager.getProperty("outputnqfile", Constants.CONFIGFILE);
		String jsonConfigFile = PropertyManager.getProperty("jsonconfigfile", Constants.CONFIGFILE);
		String json = file.readFile(jsonConfigFile);

		ObjectMapper mapper = new ObjectMapper();
		GraphDBVO dbConfig = mapper.readValue(json,GraphDBVO.class);
		
		Connector con = null;
		Set<String> cayleyQueries=new HashSet<String>();


		// varCount=Mongo.readCount()+1;
		//System.out.println("varCount value :"+varCount);

		
		//varCount=Mongo.readCount()+1;
		//System.out.println("varCount value :"+varCount);
		

		List<GraphTableVO> cayleyst=dbConfig.getConfigTable();
		for(GraphTableVO tableVO:cayleyst)
		{
			if (dbConfig.getDbType().equalsIgnoreCase("RDBMS")) {
				con = new RDBConnector();
			} else {
				con = new Mongo();
			}
		//con.getData(dbConfig,tableVO);
		cayleyQueries.addAll(con.getData(dbConfig,tableVO)); //for NQ generation
			//System.out.println("cq"+cayleyQueries);

		
		//System.out.println("cayley size"+cayleyQueries.size());


		}
		List listOfNames = new ArrayList(cayleyQueries);
		//System.out.println("listtttt!!!!"+listOfNames);
		
		System.out.println("listofnames size"+listOfNames.size());

		try {
			
			file.writeFile(listOfNames, /*dbConfig.getCayleyDirectory() + "\\" +*/ outputNQFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	   //System.out.println(JSONConnection1.readCount);
	
	    System.out.println("End Time: " + ft.format(dNow));   

	  // System.out.println(JSONConnection1.readCount);
	   System.out.println("End Time: " + ft.format(dNow));   

	
	}
}

