package com.cts.cayley.VO;

import java.util.List;

public class GraphConfigMapVO 
{
	private GraphObjVO primaryObj;
	private List<AttributeVO> attributes;
	private List<List<String>> fields;
	private String modifiedColumnName;
	
	public GraphObjVO getPrimaryObj() {
		return primaryObj;
	}
	public void setPrimaryObj(GraphObjVO primaryObj) {
		this.primaryObj = primaryObj;
	}
	public List<AttributeVO> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<AttributeVO> attributes) {
		this.attributes = attributes;
	}
	public List<List<String>> getFields() {
		return fields;
	}
	public void setFields(List<List<String>> fields) {
		this.fields = fields;
	}
	public String getModifiedColumnName() {
		return modifiedColumnName;
	}
	public void setModifiedColumnName(String modifiedColumnName) {
		this.modifiedColumnName = modifiedColumnName;
	}
	
	
	
	
	

	
	

}
