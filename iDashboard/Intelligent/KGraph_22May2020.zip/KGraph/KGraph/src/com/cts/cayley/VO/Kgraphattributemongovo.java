package com.cts.cayley.VO;


 
public class Kgraphattributemongovo {
	
	private String keyvalue;

	public String getKeyvalue() {
		return keyvalue;
	}

	public void setKeyvalue(String keyvalue) {
		this.keyvalue = keyvalue;
	}

}
