package com.cts.cayley.util;

public interface Constants {

	public static String CONFIGFILE="config.properties";
		

}

