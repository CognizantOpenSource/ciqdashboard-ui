package com.cts.cayley.VO;

import java.util.List;

public class GraphObjVO {
	
	private List<String> dbColumnNameList;
	private String dbColumnName;
	
	public String getDbColumnName() {
		return dbColumnName;
	}
	public void setDbColumnName(String dbColumnName) {
		this.dbColumnName = dbColumnName;
	}
	private String key;
	
	public List<String> getDbColumnNameList() {
		return dbColumnNameList;
	}
	public void setDbColumnNameList(List<String> dbColumnNameList) {
		this.dbColumnNameList = dbColumnNameList;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	}
