package com.cts.cayley.VO;

import java.io.Serializable;
import java.util.ArrayList;

public class GraphTableVO implements Serializable
{
	private String dbName;
	private String query;
	private GraphConfigMapVO config;
	private ArrayList<String> collectionquery;
	private String table;
	/*private String getQueryCount;
	
	public String getGetQueryCount() {
		return getQueryCount;
	}
	public void setGetQueryCount(String getQueryCount) {
		this.getQueryCount = getQueryCount;
	}*/
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public GraphConfigMapVO getConfig() {
		return config;
	}
	public void setConfig(GraphConfigMapVO config) {
		this.config = config;
	}
	public ArrayList<String> getCollectionquery() {
		return collectionquery;
	}
	public void setCollectionquery(ArrayList<String> collectionquery) {
		this.collectionquery = collectionquery;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
}
