package com.cts.cayley.NQ.DAO;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.entity.StringEntity;
import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.cts.cayley.DAO.CayleyApiConnector;
import com.cts.cayley.VO.AttributeVO;
import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphConfigMapVO;
import com.cts.cayley.VO.GraphTableVO;
import com.cts.cayley.process.FileIO;
import com.cts.tokenizer.process.Tokenizer;
import com.mongodb.util.JSON;

public abstract class Connector {
	
   
                public final String QUERYDBLQUOTE = "\"";
                public final String QUERYDBLQUOTE2 = "\" \""; 
                public final String QUERYDBLQUOTEWITHN = "\".\n";
                public final String QUERYOFTYPE = "of type";
                public final String QUERYISA = "is a";
                public final String QUERYNLPABLE = "is NLPable";
                public final String QUERYSMALLRELATION = "relation";
                public final String QUERYCAPSRELATION = "Relation";
                public final String QUERYGROUPABLE = "is groupable";
                public final String QUERYNLP = "is NLPable";
                public final String QUERYCONTAINS="contains";                
                public final String QUERYPRIMEKEYDELIMITER = "$";
                public final String QUERYDATATYPE = "data type";
                public final String QUERYALIAS="relation alias";
                public final String QUERYOFTYPEALIAS="Alias";
                public final String QUERYTOKENIZEALIAS="alias";
                public final String QUERYTOKENIZE="tokenize";
                public final String QUERYOFTYPETOKENIZE="Tokenize";
                private final String TOKENIZER_DELIMITER = " '@','-',',' ',''' ";
                String subject;
                String predicate;
                String object;
                

                
                String dbleqt ="\"\"";
                
                //String dbleqt ="";
                public abstract Set<String> getData(GraphDBVO configs, GraphTableVO configTable);

                // generate relations string for a record
                public Set<String> formQuery(GraphConfigMapVO configs,
                                                HashMap<String, String> columnsMap) throws JSONException   {
                                
                                String id = "$";
                                String type = "Object";
                                String nlptrue="true";
                                Set<String> cayleyQuery = new HashSet<String>();
                                String attribute, relation,isGroupable, nlpFeed,key = null,attributekey,datatype,aliasform;
                                String linkvalue = "";
                                String cayleyOfTypeQuery,cayleyNLPQuery;
                                String cayleyIsAAttributeQuery;
                                String cayleymultipleprimarykeyQuery = "";
                                String linkValue= "";
                                String idValue="";
                                boolean extractKeyword;
                                attributekey = configs.getPrimaryObj().getKey();
                                //System.out.println("attrrrrrr!!!"+attributekey);
                                JSONArray jsonArray= new JSONArray();
                                
                                //System.out.println("db" +dbleqt);
                                
                                for (int i = 0; i < configs.getPrimaryObj().getDbColumnNameList().size(); i++) {
                                                idValue=columnsMap.get(configs.getPrimaryObj().getDbColumnNameList().get(i));
                                                if(idValue!=null && !idValue.isEmpty())
                                                id += idValue + "$";
                                }
                                
                                //adding escape character to "
                                if(idValue!=null)
                                	id.replaceAll("\"", "\\\"").replaceAll("\n","");
                                //JSONObject json= new JSONObject();
                                
                                cayleyOfTypeQuery = QUERYDBLQUOTE  + attributekey  + QUERYDBLQUOTE2 + QUERYOFTYPE + QUERYDBLQUOTE2 + type + QUERYDBLQUOTEWITHN;
                                //System.out.println("cayoff"+cayleyOfTypeQuery);
                                JSONObject json= new JSONObject();
                                json.put("subject",attributekey);
                                json.put("predicate",QUERYOFTYPE);
                                json.put("object",type);
                                
                                //System.out.println("josn!!!!!"+json);
                                jsonArray.put(json);
                                CayleyApiConnector obj = new CayleyApiConnector();
                               /* try {
                                	obj.executeArray(new StringEntity(jsonArray.toString()));
                                } catch (IOException e) {
                                	// TODO Auto-generated catch block
                                	e.printStackTrace();
                                }*/
                                
                                //JSONObject json1= new JSONObject();
                               
                                cayleyIsAAttributeQuery = QUERYDBLQUOTE  + id  + QUERYDBLQUOTE2 + QUERYISA + QUERYDBLQUOTE2 + attributekey + QUERYDBLQUOTEWITHN;
                                 
                                 jsonArray= new JSONArray();
                                JSONObject json1= new JSONObject();
                                json1.put("subject",id);
                                json1.put("predicate",QUERYISA);
                                json1.put("object",attributekey);
                                jsonArray.put(json1);
                               
                               /* try {
                                	obj.executeArray(new StringEntity(jsonArray.toString()));
                                } catch (IOException e) {
                                	// TODO Auto-generated catch block
                                	e.printStackTrace();
                                }*/
                                
                                cayleyNLPQuery = QUERYDBLQUOTE  + attributekey  + QUERYDBLQUOTE2 + QUERYNLPABLE + QUERYDBLQUOTE2 + nlptrue + QUERYDBLQUOTEWITHN;
                                cayleyQuery.add(cayleyOfTypeQuery);
                                cayleyQuery.add(cayleyIsAAttributeQuery);
                                cayleyQuery.add(cayleyNLPQuery);
                
                            /* System.out.println("c12"+cayleyOfTypeQuery);
                                System.out.println("c13"+cayleyIsAAttributeQuery);*/
                //System.out.println("value of config size:::"+configs.getAttributes().size());
                
                for (int i = 0; i < configs.getAttributes().size(); i++) {
                	
                                                String cayleyGroupableQuery;
                                                String cayleyNlpQuery;
                                                String cayleyNlpQuery2;
                                                String cayleyOfTypeQuery2;
                                                String cayleyOfTypeQuery3;
                                                String cayleyOfTypeQuery4="";
                                                String cayleyIsAAttributeQuery1;
                                                String cayleyrelationQuery3 = "";
                                                String cayleyRelationQuery;
                                                String cayleyrelationQuery;
                                                String cayleydatatypeQuery = "";
                                                String cayleyaliasquery = "";
                                                String cayleyOfTypeQuery5;
                                                String  cayleyOfTypeQuery6;
                                                String cayleyOfTypeQuery7;
                                                boolean tokenize=false;
                                                ArrayList<String> tokenizedkey=null;
                                                ArrayList<String> tokenized = null;
                                                ArrayList<String> tokenizedobj=null;
                                                List<String> variableAlias= new ArrayList<String>();
                                                String cayleyVariableAliasQuery;
                                                //String subject;
                                                //String predicate;
                                                //String object;
                                
                                                String ssd=configs.getAttributes().get(i).getDbColumnName();
                                                attribute = columnsMap.get(configs.getAttributes().get(i).getDbColumnName());
                                                //adding escape character to "
                                                
                                                
                                                //handling ISO date format from mongo
                                                if((attribute!=null )&& (!attribute.isEmpty()) && (attribute.contains("$date")))
                                                {
                                                	Date date = Date.from( Instant.parse( new JSONObject(attribute).getString("$date") ));

                                        			attribute = new SimpleDateFormat("yyyy-MM-dd").format(date); 
                                                }
                                                
                                                relation = configs.getAttributes().get(i).getRelation();
                                                type = configs.getAttributes().get(i).getType();
                                                isGroupable = configs.getAttributes().get(i).getIsGroupable();
                                                nlpFeed = configs.getAttributes().get(i).getNlpFeed();
                                                key = configs.getAttributes().get(i).getKey();
                                                extractKeyword = configs.getAttributes().get(i).isExtractKeyword();
                                                datatype = configs.getAttributes().get(i).getDataType();
                                                aliasform= configs.getAttributes().get(i).getAlias();
                                                tokenize=configs.getAttributes().get(i).isTokenize();
                                                variableAlias = configs.getAttributes().get(i).getVariableAlias();
                                                String subject;
                                                String predicate;
                                                String object;
                                           	 
                                                
                                                	 if(attribute!=null && !attribute.isEmpty()) 
                                                {
                                                		 attribute = attribute.replaceAll("\"","\\\"").replaceAll("\n","");
                                                		 tokenizedobj=Tokenizer.tokenize(attributekey, " ");	 
                                                		 String cayleyObjTokenize="";
                                                     	
                                                		 if(tokenizedobj.size()>1)
                                                		 {
                                                			 for(String itr:tokenizedobj)
                                                			 {
                                                				 jsonArray= new JSONArray();
                                                				 JSONObject json20= new JSONObject();
                                                				 cayleyObjTokenize= QUERYDBLQUOTE  + attributekey  + QUERYDBLQUOTE2 + QUERYTOKENIZE + QUERYDBLQUOTE2 + itr + QUERYDBLQUOTEWITHN;
                                                				 //System.out.println("obj!!!!!!"+ cayleyObjTokenize);
                                                				
                                                				 cayleyQuery.add(cayleyObjTokenize);
                                                				json20= new JSONObject();
                                                				 json20.put("subject", attributekey);
                                                				 json20.put("predicate",QUERYTOKENIZE);
                                                				 json20.put("object",itr);
                                                				 
                                                				 jsonArray.put(json20);
                                                				/* try {
                                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                 } catch (IOException e) {
                                                                 	// TODO Auto-generated catch block
                                                                 	e.printStackTrace();
                                                                 }*/
                                                				 //System.out.println("json"+jsonArray);
                                                			 }
                                                		 }
                                                		 
                                                		 
															
															
															
                                                		 tokenizedkey= Tokenizer.tokenize(key," ");
                                                		 //System.out
																//.println("Key"+tokenizedkey);
                                                		 String cayleyKeyTokenize="";
                                                	
                                                		 if(tokenizedkey.size()>1)
                                                		 {
                                                			 for(String iterator:tokenizedkey)
                                                			 {
                                                				 jsonArray= new JSONArray();
                                                				 JSONObject json2= new JSONObject();
                                                				 cayleyKeyTokenize= QUERYDBLQUOTE  + key  + QUERYDBLQUOTE2 + QUERYTOKENIZE + QUERYDBLQUOTE2 + iterator + QUERYDBLQUOTEWITHN;
                                                				 //System.out.println("Keyquery"+ cayleyKeyTokenize);
                                                				
                                                				 cayleyQuery.add(cayleyKeyTokenize);
                                                				json2= new JSONObject();
                                                				 json2.put("subject", key);
                                                				 json2.put("predicate",QUERYTOKENIZE);
                                                				 json2.put("object",iterator);
                                                				 
                                                				 jsonArray.put(json2);
                                                				 /*try {
                                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                 } catch (IOException e) {
                                                                 	// TODO Auto-generated catch block
                                                                 	e.printStackTrace();
                                                                 }*/
                                                				 //System.out.println("json"+jsonArray);
                                                			 }
                                                		 }
                                                		 
                                                		 
                                                		 
                                                		 
                                                		 
                                                		 
                                                		 if (tokenize==true)
                                                         {
                                                	tokenized=Tokenizer.tokenize(attribute,TOKENIZER_DELIMITER);
                                                                String cayleyTokenizeQuery="";
                                                                 
                                                                JSONObject json3=new JSONObject();
                                                                JSONObject json4= new JSONObject();
                                                                if(tokenized.size()>1)
                                                                {
                                                                                for(String iterator:tokenized)
                                                                                {
                                                                                                cayleyTokenizeQuery = QUERYDBLQUOTE  + attribute  + QUERYDBLQUOTE2 + QUERYTOKENIZEALIAS + QUERYDBLQUOTE2 + iterator + QUERYDBLQUOTEWITHN;
                                                                                                cayleyQuery.add(cayleyTokenizeQuery);
                                                                                                jsonArray= new JSONArray();
                                                                                                json3=new JSONObject();
                                                                                                json3.put("subject",attribute);
                                                                                                json3.put("predicate",QUERYTOKENIZEALIAS);
                                                                                                json3.put("object",iterator);
                                                                                                jsonArray.put(json3);
                                                                                               /* try {
                                                                                                	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                                                } catch (IOException e) {
                                                                                                	// TODO Auto-generated catch block
                                                                                                	e.printStackTrace();
                                                                                                }*/
                                                                                                //System.out.println(json1);
																										
                                                                                                //System.out.println("jsonArray"+json1.toString());
                                                                                               /*System.out.println("R12" +cayleyTokenizeQuery);*/
                                                                                                cayleyOfTypeQuery5=  QUERYDBLQUOTE  + iterator  + QUERYDBLQUOTE2 + QUERYOFTYPE  + QUERYDBLQUOTE2 + QUERYOFTYPEALIAS + QUERYDBLQUOTEWITHN;
                                                                                                cayleyQuery.add(cayleyOfTypeQuery5);
                                                                                                jsonArray= new JSONArray();
                                                                                                json4=new JSONObject();
                                                                                                json4.put("subject",iterator);
                                                                                                json4.put("predicate",QUERYOFTYPE);
                                                                                                json4.put("object",QUERYOFTYPEALIAS);
                                                                                                jsonArray.put(json4);
                                                                                                /*try {
                                                                                                	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                                                } catch (IOException e) {
                                                                                                	// TODO Auto-generated catch block
                                                                                                	e.printStackTrace();
                                                                                                }*/
                                                                                                
                                                                                                //System.out.println("jsonArray"+json2.toString());
                                                                                               /* System.out.println("R13"   +cayleyOfTypeQuery5);*/
                                                                                }
                                                
                                                                //Tokenizer.tokenize(String name);
                                                                //String cayleyContainsQuery = QUERYDBLQUOTE + attribute + QUERYDBLQUOTE2+ QUERYCONTAINS + QUERYDBLQUOTE2 + relation + QUERYDBLQUOTEWITHN;
                                                                //cayleyQuery.add(cayleyContainsQuery);
                                                                //System.out.println("query11********" + cayleyContainsQuery);
                                                    }
                                                }
                                                	 
                                                 
                                                	 else 
                                                	 {
                                                		 
                                                		 tokenized=Tokenizer.tokenize(attribute," ");
                                                		JSONObject json5= new JSONObject();
                                                		
                                                         String cayleyTokenizeQuery1="";
                                                         if(tokenized.size()>1)
                                                         {
                                                                         for(String iterator:tokenized)
                                                                         {
                                                                                         cayleyTokenizeQuery1 = QUERYDBLQUOTE  + attribute  + QUERYDBLQUOTE2 + QUERYTOKENIZE + QUERYDBLQUOTE2 + iterator + QUERYDBLQUOTEWITHN;
                                                                                         cayleyQuery.add(cayleyTokenizeQuery1);
                                                                                         jsonArray= new JSONArray();
                                                                                         json5= new JSONObject();
                                                                                         json5.put("subject", attribute);
                                                                                         json5.put("predicate", QUERYTOKENIZE);
                                                                                         json5.put("object", iterator);
                                                                                         //System.out.println("jsonnnn22222222"+json5);
                                                                                         jsonArray.put(json5);
                                                                                       
                                                                                        /* try {
                                                                                         	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                                         } catch (IOException e) {
                                                                                         	// TODO Auto-generated catch block
                                                                                         	e.printStackTrace();
                                                                                         }*/
                                                                                        /*System.out.println("R12" +cayleyTokenizeQuery);*/
                                                                                         //cayleyOfTypeQuery7=  QUERYDBLQUOTE + dbleqt + iterator + dbleqt + QUERYDBLQUOTE2 + QUERYOFTYPE  + QUERYDBLQUOTE2 + QUERYOFTYPETOKENIZE + QUERYDBLQUOTEWITHN;
                                                                                         //cayleyQuery.add(cayleyOfTypeQuery7);
                                                                                        /* System.out.println("R13"   +cayleyOfTypeQuery5);*/
                                                                         }
                                         
                                                         
                                             }
                                                		 
                                                		 
                                                		 
                                                		 
                                                	 }
                                                }
                                                
                                                
                if(variableAlias.size()>0)
                {
                	for(String defect:variableAlias)
                	{
                		JSONObject json6= new JSONObject();
                		JSONObject json7= new JSONObject();
                		
                	cayleyVariableAliasQuery=  QUERYDBLQUOTE  + relation  + QUERYDBLQUOTE2 + QUERYTOKENIZEALIAS + QUERYDBLQUOTE2 + defect + QUERYDBLQUOTEWITHN;
                	cayleyQuery.add(cayleyVariableAliasQuery);
                	 jsonArray= new JSONArray();
                	json6=new JSONObject();
                	json6.put("subject", relation);
                	json6.put("predicate", QUERYTOKENIZEALIAS);
                	json6.put("object", defect);
                	
                	jsonArray.put(json6);
                	/* try {
                      	obj.executeArray(new StringEntity(jsonArray.toString()));
                      } catch (IOException e) {
                      	// TODO Auto-generated catch block
                      	e.printStackTrace();
                      }*/
                	 cayleyOfTypeQuery6=  QUERYDBLQUOTE  + defect  + QUERYDBLQUOTE2 + QUERYOFTYPE  + QUERYDBLQUOTE2 + QUERYOFTYPEALIAS + QUERYDBLQUOTEWITHN;
                	 cayleyQuery.add(cayleyOfTypeQuery6);
                	 jsonArray= new JSONArray();
                	 json7=new JSONObject();
                	 json7.put("subject", defect);
                	 json7.put("predicate", QUERYOFTYPE);
                	 json7.put("object", QUERYOFTYPEALIAS);
                	 jsonArray.put(json7);
                	 /*try {
                      	obj.executeArray(new StringEntity(jsonArray.toString()));
                      } catch (IOException e) {
                      	// TODO Auto-generated catch block
                      	e.printStackTrace();
                      }*/
                	}
                }
                                                if((type.equals("Object"))&& (attribute!=null)&& (!attribute.isEmpty())) {          
                                                                attribute = "$"+attribute+"$";
                                                                //adding escape character to "
                                                                attribute = attribute.replaceAll("\"", "\\\"").replaceAll("\n","");
                                                                linkvalue="$";
                                                                for (int k = 0; k < configs.getAttributes().get(i).getPrimaryKey().size();k++)  {
                                                                                linkValue=  columnsMap.get(configs.getAttributes().get(i).getPrimaryKey().get(k));
                                                                                if(linkValue!=null && !linkValue.isEmpty())
                                                                                                linkvalue += linkValue + "$";
                                                                
                                                                }
                                                                
                                                                //adding escape character to "
                                                                if(linkValue!=null)
                                                                	linkvalue = linkvalue.replaceAll("\"", "\\\"").replaceAll("\n","");
                                                                JSONObject json8= new JSONObject();
                                                                
                                                                
                                                                cayleymultipleprimarykeyQuery=QUERYDBLQUOTE  + id  + QUERYDBLQUOTE2 + relation + QUERYDBLQUOTE2 + linkvalue + QUERYDBLQUOTEWITHN;
                                                                cayleyQuery.add(cayleymultipleprimarykeyQuery);
                                                                jsonArray= new JSONArray();
                                                                json8=new JSONObject();
                                                                json8.put("subject", id);
                                                                json8.put("predicate", relation);
                                                                json8.put("object", linkvalue);
                                                                jsonArray.put(json8);
                                                              /* try {
                                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                 } catch (IOException e) {
                                                                 	// TODO Auto-generated catch block
                                                                 	e.printStackTrace();
                                                                 }*/
                                                                //System.out.println(cayleymultipleprimarykeyQuery);
                                                              
                                                              //System.out.println("c16"+cayleymultipleprimarykeyQuery); 
                                                                
                                                
                                                                
                                                }
                                                else
                                                {          
                                                                
                                                	cayleyrelationQuery3= QUERYDBLQUOTE  + id  + QUERYDBLQUOTE2 + relation + QUERYDBLQUOTE2 + attribute  + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();        
                                                JSONObject json9= new JSONObject();
                                                                json9=new JSONObject();
                                                                json9.put("subject", id);
                                                                json9.put("predicate", relation);
                                                                json9.put("object", attribute);
                                                               
                                                                jsonArray.put(json9);
                                                                /*try {
                                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                 } catch (IOException e) {
                                                                 	// TODO Auto-generated catch block
                                                                 	e.printStackTrace();
                                                                 }*/
                                                
                                                if(attribute!=null && !attribute.isEmpty()) {         
                                                                
                                                //            attribute = "$"+attribute+"$";
                                                	
                                                	JSONObject json10= new JSONObject();
                                                	JSONObject json11= new JSONObject();
                                                	JSONObject json12= new JSONObject();
                                                	JSONObject json13= new JSONObject();
                                                	JSONObject json14= new JSONObject();
                                                	JSONObject json15= new JSONObject();
                                                	JSONObject json16= new JSONObject();
                                                	JSONObject json17= new JSONObject();
                                                	
                                                cayleyGroupableQuery = QUERYDBLQUOTE  +key + QUERYDBLQUOTE2 + QUERYGROUPABLE + QUERYDBLQUOTE2 + isGroupable + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                json10=new JSONObject();
                                                json10.put("subject", key);
                                                json10.put("predicate", QUERYGROUPABLE);
                                                json10.put("object", isGroupable);
                                                jsonArray.put(json10);
                                                /*try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                
                                                cayleyOfTypeQuery2 = QUERYDBLQUOTE  + key + QUERYDBLQUOTE2 + QUERYOFTYPE + QUERYDBLQUOTE2 + type + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                 json11=new JSONObject();
                                                json11.put("subject", key);
                                                json11.put("predicate", QUERYOFTYPE);
                                                json11.put("object", type);
                                                jsonArray.put(json11);
                                               /* try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                cayleyNlpQuery = QUERYDBLQUOTE  + attribute  + QUERYDBLQUOTE2 + QUERYNLP + QUERYDBLQUOTE2 + nlpFeed + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                 json12=new JSONObject();
                                                json12.put("subject", attribute);
                                                json12.put("predicate", QUERYNLP);
                                                json12.put("object", nlpFeed);
                                                jsonArray.put(json12);
                                               /* try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                cayleyNlpQuery2 = QUERYDBLQUOTE + key  + QUERYDBLQUOTE2 + QUERYNLP + QUERYDBLQUOTE2 + nlpFeed + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                 json13=new JSONObject();
                                                json13.put("subject", key);
                                                json13.put("predicate", QUERYNLP);
                                                json13.put("object", nlpFeed);
                                                jsonArray.put(json13);
                                                /*try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                cayleyRelationQuery = QUERYDBLQUOTE  + relation  +QUERYDBLQUOTE2 + QUERYSMALLRELATION + QUERYDBLQUOTE2 + key + QUERYDBLQUOTEWITHN;
                                               
                                                jsonArray= new JSONArray();
                                                json14=new JSONObject();
                                                json14.put("subject", relation);
                                                json14.put("predicate", QUERYSMALLRELATION);
                                                json14.put("object", key);
                                                jsonArray.put(json14);
                                               /* try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                cayleyIsAAttributeQuery1 = QUERYDBLQUOTE  + attribute  + QUERYDBLQUOTE2 + QUERYISA + QUERYDBLQUOTE2 + key + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                json15=new JSONObject();
                                                json15.put("subject", attribute);
                                                json15.put("predicate", QUERYISA);
                                                json15.put("object", key);
                                                jsonArray.put(json15);
                                               /* try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                cayleyOfTypeQuery3 = QUERYDBLQUOTE  + relation  + QUERYDBLQUOTE2 + QUERYOFTYPE + QUERYDBLQUOTE2 + QUERYCAPSRELATION + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                json16=new JSONObject();
                                                json16.put("subject", relation);
                                                json16.put("predicate", QUERYOFTYPE);
                                                json16.put("object", QUERYCAPSRELATION);
                                                jsonArray.put(json16);
                                               /* try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                
                                                cayleyrelationQuery = QUERYDBLQUOTE  + attributekey  + QUERYDBLQUOTE2 + QUERYSMALLRELATION + QUERYDBLQUOTE2 + relation + QUERYDBLQUOTEWITHN;
                                                jsonArray= new JSONArray();
                                                json17=new JSONObject();
                                                json17.put("subject", attributekey);
                                                json17.put("predicate", QUERYSMALLRELATION);
                                                json17.put("object", relation);
                                                jsonArray.put(json17);
                                               /* try {
                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                 } catch (IOException e) {
                                                 	// TODO Auto-generated catch block
                                                 	e.printStackTrace();
                                                 }*/
                                                if(type.equals("Object")) {
                                                	JSONObject json18= new JSONObject();
                                                                cayleyaliasquery=QUERYDBLQUOTE  + relation + QUERYDBLQUOTE2 + QUERYALIAS + QUERYDBLQUOTE2 + aliasform + QUERYDBLQUOTEWITHN;
                                                                jsonArray= new JSONArray();
                                                                json18=new JSONObject();
                                                                json18.put("subject", relation);
                                                                json18.put("predicate", QUERYALIAS);
                                                                json18.put("object", aliasform);
                                                                jsonArray.put(json18);
                                                                /*try {
                                                                 	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                                 } catch (IOException e) {
                                                                 	// TODO Auto-generated catch block
                                                                 	e.printStackTrace();
                                                                 }*/
                                                }
                                                
                                                else  {
                                                	JSONObject json19= new JSONObject();
                                                  cayleydatatypeQuery=QUERYDBLQUOTE  + key  + QUERYDBLQUOTE2 + QUERYDATATYPE + QUERYDBLQUOTE2 + datatype + QUERYDBLQUOTEWITHN; 
                                                  jsonArray= new JSONArray();
                                                  json19=new JSONObject();
                                                  json19.put("subject", key);
                                                  json19.put("predicate", QUERYDATATYPE);
                                                  json19.put("object", datatype);
                                                  jsonArray.put(json19); 
                                                /*  try {
                                                   	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                   } catch (IOException e) {
                                                   	// TODO Auto-generated catch block
                                                   	e.printStackTrace();
                                                   }*/
                                                  } 
                
                                
                                                
                                                cayleyQuery.add(cayleyrelationQuery);
                                                cayleyQuery.add(cayleyNlpQuery);
                                                cayleyQuery.add(cayleyGroupableQuery);
                                                cayleyQuery.add(cayleyRelationQuery);
                                                cayleyQuery.add(cayleyOfTypeQuery2);
                                                cayleyQuery.add(cayleyOfTypeQuery3);
                                                cayleyQuery.add(cayleyOfTypeQuery4);
                                                cayleyQuery.add(cayleyIsAAttributeQuery1);
                                                cayleyQuery.add(cayleyrelationQuery3);
                                                cayleyQuery.add(cayleyNlpQuery2);
                                                cayleyQuery.add(cayleydatatypeQuery);
                                                cayleyQuery.add(cayleyaliasquery);
                                                
                                                
                                                
                                
                                                
                                               /* System.out.println("c1"+cayleyNlpQuery);
                                                System.out.println("c2"+cayleyGroupableQuery);
                                                System.out.println("c3"+cayleyRelationQuery);
                                               System.out.println("c4"+cayleyOfTypeQuery2);
                                                System.out.println("c5"+cayleyOfTypeQuery3);
                                                System.out.println("c7"+cayleyIsAAttributeQuery1);
                                                System.out.println("c8"+cayleyrelationQuery);
                                                System.out.println("c9"+cayleyrelationQuery3);               
                                                System.out.println("c10"+cayleyNlpQuery2);
                                                System.out.println("c11"+cayleydatatypeQuery);
                                                System.out.println("c15"+cayleyaliasquery);*/
                                                
                                
                                                
                                
                                                }
                                                }
                                              /*  System.out.println("json arrayyyy isssss"+jsonArray+"size"+jsonArray.length());
                                              
                                                JSONConnection obj = new JSONConnection();
                                                try {
                                                	obj.executeArray(new StringEntity(jsonArray.toString()));
                                                } catch (IOException e) {
                                                	// TODO Auto-generated catch block
                                                	e.printStackTrace();
                                                }
                                                System.out
												.println("i value is :"+i);*/
}
                
                                
                

                return cayleyQuery;
                
}
}
