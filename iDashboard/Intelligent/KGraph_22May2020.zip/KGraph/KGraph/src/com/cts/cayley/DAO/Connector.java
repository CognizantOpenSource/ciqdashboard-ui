package com.cts.cayley.DAO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.http.entity.StringEntity;
import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.cts.cayley.VO.GraphConfigMapVO;
import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphTableVO;
import com.cts.tokenizer.process.Tokenizer;

public abstract class Connector {

	public final String QUERYDBLQUOTE = "\"";
	public final String QUERYDBLQUOTE2 = "\" \"";
	public final String QUERYDBLQUOTEWITHN = "\".\n";
	public final String QUERYOFTYPE = "of type";
	public final String QUERYISA = "is a";
	public final String QUERYSMALLRELATION = "relation";
	public final String QUERYCAPSRELATION = "Relation";
	public final String QUERYGROUPABLE = "is groupable";
	public final String QUERYNLP = "is NLPable";
	public final String QUERYCONTAINS = "contains";
	public final String QUERYPRIMEKEYDELIMITER = "$";
	public final String QUERYDATATYPE = "data type";
	public final String QUERYALIAS = "relation alias";
	public final String QUERYOFTYPEALIAS = "Alias";
	public final String QUERYTOKENIZEALIAS = "alias";
	public final String QUERYTOKENIZE = "tokenize";
	public final String QUERYOFTYPETOKENIZE = "Tokenize";
	private final String TOKENIZER_DELIMITER = " '@','-',',' ',''' ";

	// String dbleqt ="\"\"";
	String dbleqt = "";

	public abstract void getData(GraphDBVO configs, GraphTableVO configTable);

	// generate relations string for a record
	public void formQuery(GraphConfigMapVO configs,
			HashMap<String, String> columnsMap) throws JSONException {

		String id = "$";
		String type = "Object";
		Set<String> cayleyQuery = new HashSet<String>();
		String attribute, relation, isGroupable, nlpFeed, key = null, attributekey, datatype, aliasform;
		String linkvalue = "";
		String cayleyOfTypeQuery;
		String cayleyIsAAttributeQuery;
		String cayleymultipleprimarykeyQuery = "";
		String linkValue = "";
		String idValue = "";
		boolean extractKeyword;
		attributekey = configs.getPrimaryObj().getKey();

		for (int i = 0; i < configs.getPrimaryObj().getDbColumnNameList()
				.size(); i++) {
			idValue = columnsMap.get(configs.getPrimaryObj()
					.getDbColumnNameList().get(i));
			if (idValue != null && !idValue.isEmpty())
				id += idValue + "$";
		}

		// JSONObject json= new JSONObject();

		cayleyOfTypeQuery = QUERYDBLQUOTE + dbleqt + attributekey + dbleqt
				+ QUERYDBLQUOTE2 + QUERYOFTYPE + QUERYDBLQUOTE2 + type
				+ QUERYDBLQUOTEWITHN;

		
		CayleyApiConnector.insertIntoDB(attributekey,QUERYOFTYPE,type);
		

		cayleyIsAAttributeQuery = QUERYDBLQUOTE + dbleqt + id + dbleqt
				+ QUERYDBLQUOTE2 + QUERYISA + QUERYDBLQUOTE2 + attributekey
				+ QUERYDBLQUOTEWITHN;
		
		CayleyApiConnector.insertIntoDB(id,QUERYISA,attributekey);
		
		cayleyQuery.add(cayleyOfTypeQuery);
		cayleyQuery.add(cayleyIsAAttributeQuery);

		// System.out.println("value of config size:::"+configs.getAttributes().size());

		for (int i = 0; i < configs.getAttributes().size(); i++) {

			String cayleyGroupableQuery;
			String cayleyNlpQuery;
			String cayleyNlpQuery2;
			String cayleyOfTypeQuery2;
			String cayleyOfTypeQuery3;
			String cayleyOfTypeQuery4 = "";
			String cayleyIsAAttributeQuery1;
			String cayleyrelationQuery3 = "";
			String cayleyRelationQuery;
			String cayleyrelationQuery;
			String cayleydatatypeQuery = "";
			String cayleyaliasquery = "";
			String cayleyOfTypeQuery5;
			String cayleyOfTypeQuery6;
			boolean tokenize = false;
			ArrayList<String> tokenizedkey = null;
			ArrayList<String> tokenized = null;
			ArrayList<String> tokenizedobj = null;
			List<String> variableAlias = new ArrayList<String>();
			String cayleyVariableAliasQuery;
			// String subject;
			// String predicate;
			// String object;

			attribute = columnsMap.get(configs.getAttributes().get(i)
					.getDbColumnName());
			if (attribute != null && !attribute.isEmpty()) // conditions
				attribute = attribute.replaceAll("\"", "'")
						.replaceAll("\n", "");

			relation = configs.getAttributes().get(i).getRelation();
			type = configs.getAttributes().get(i).getType();
			isGroupable = configs.getAttributes().get(i).getIsGroupable();
			nlpFeed = configs.getAttributes().get(i).getNlpFeed();
			key = configs.getAttributes().get(i).getKey();
			extractKeyword = configs.getAttributes().get(i).isExtractKeyword();
			datatype = configs.getAttributes().get(i).getDataType();
			aliasform = configs.getAttributes().get(i).getAlias();
			tokenize = configs.getAttributes().get(i).isTokenize();
			variableAlias = configs.getAttributes().get(i).getVariableAlias();

			if (attribute != null && !attribute.isEmpty()) {

				tokenizedobj = Tokenizer.tokenize(attributekey, " ");

				String cayleyObjTokenize = "";

				if (tokenizedobj.size() > 1) {
					for (String itr : tokenizedobj) {
						
						cayleyObjTokenize = QUERYDBLQUOTE + attributekey
								+ QUERYDBLQUOTE2 + QUERYTOKENIZE
								+ QUERYDBLQUOTE2 + itr + QUERYDBLQUOTEWITHN;

						CayleyApiConnector.insertIntoDB(attributekey,QUERYTOKENIZE,itr);
						
						cayleyQuery.add(cayleyObjTokenize);
						

					}
				}

				tokenizedkey = Tokenizer.tokenize(key, " ");

				String cayleyKeyTokenize = "";
				if (tokenizedkey.size() > 1) {
					for (String iterator : tokenizedkey) {
						
						cayleyKeyTokenize = QUERYDBLQUOTE + dbleqt + key
								+ dbleqt + QUERYDBLQUOTE2 + QUERYTOKENIZE
								+ QUERYDBLQUOTE2 + iterator
								+ QUERYDBLQUOTEWITHN;

						cayleyQuery.add(cayleyKeyTokenize);
						
						CayleyApiConnector.insertIntoDB(key,QUERYTOKENIZE,iterator);
						

					}
				}

				if (tokenize == true) {
					tokenized = Tokenizer.tokenize(attribute,
							TOKENIZER_DELIMITER);
					String cayleyTokenizeQuery = "";

					if (tokenized.size() > 1) {
						for (String iterator : tokenized) {
							cayleyTokenizeQuery = QUERYDBLQUOTE + dbleqt
									+ attribute + dbleqt + QUERYDBLQUOTE2
									+ QUERYTOKENIZEALIAS + QUERYDBLQUOTE2
									+ iterator + QUERYDBLQUOTEWITHN;
							cayleyQuery.add(cayleyTokenizeQuery);
							
							CayleyApiConnector.insertIntoDB(attribute,QUERYTOKENIZEALIAS,iterator);
							
							cayleyOfTypeQuery5 = QUERYDBLQUOTE + dbleqt
									+ iterator + dbleqt + QUERYDBLQUOTE2
									+ QUERYOFTYPE + QUERYDBLQUOTE2
									+ QUERYOFTYPEALIAS + QUERYDBLQUOTEWITHN;
							cayleyQuery.add(cayleyOfTypeQuery5);
							
							CayleyApiConnector.insertIntoDB(iterator,QUERYOFTYPE,QUERYOFTYPEALIAS);
							
						}

						// Tokenizer.tokenize(String name);
						// String cayleyContainsQuery = QUERYDBLQUOTE +
						// attribute + QUERYDBLQUOTE2+ QUERYCONTAINS +
						// QUERYDBLQUOTE2 + relation + QUERYDBLQUOTEWITHN;
						// cayleyQuery.add(cayleyContainsQuery);
						// System.out.println("query11********" +
						// cayleyContainsQuery);
					}
				}

				else {

					tokenized = Tokenizer.tokenize(attribute, " ");

					String cayleyTokenizeQuery1 = "";
					if (tokenized.size() > 1) {
						for (String iterator : tokenized) {
							cayleyTokenizeQuery1 = QUERYDBLQUOTE + dbleqt
									+ attribute + dbleqt + QUERYDBLQUOTE2
									+ QUERYTOKENIZE + QUERYDBLQUOTE2 + iterator
									+ QUERYDBLQUOTEWITHN;
							cayleyQuery.add(cayleyTokenizeQuery1);
							
							CayleyApiConnector.insertIntoDB(attribute,QUERYTOKENIZE,iterator);
							
							/* System.out.println("R12" +cayleyTokenizeQuery); */
							// cayleyOfTypeQuery7= QUERYDBLQUOTE + dbleqt +
							// iterator + dbleqt + QUERYDBLQUOTE2 + QUERYOFTYPE
							// + QUERYDBLQUOTE2 + QUERYOFTYPETOKENIZE +
							// QUERYDBLQUOTEWITHN;
							// cayleyQuery.add(cayleyOfTypeQuery7);
							/* System.out.println("R13" +cayleyOfTypeQuery5); */
						}

					}

				}
			}

			if (variableAlias.size() > 0) {
				for (String defect : variableAlias) {

					cayleyVariableAliasQuery = QUERYDBLQUOTE + dbleqt
							+ relation + dbleqt + QUERYDBLQUOTE2
							+ QUERYTOKENIZEALIAS + QUERYDBLQUOTE2 + defect
							+ QUERYDBLQUOTEWITHN;
					cayleyQuery.add(cayleyVariableAliasQuery);
					CayleyApiConnector.insertIntoDB(relation,QUERYTOKENIZEALIAS,defect);
					
					cayleyOfTypeQuery6 = QUERYDBLQUOTE + dbleqt + defect
							+ dbleqt + QUERYDBLQUOTE2 + QUERYOFTYPE
							+ QUERYDBLQUOTE2 + QUERYOFTYPEALIAS
							+ QUERYDBLQUOTEWITHN;
					cayleyQuery.add(cayleyOfTypeQuery6);
					CayleyApiConnector.insertIntoDB(defect,QUERYOFTYPE,QUERYOFTYPEALIAS);
					
				}
			}
			if (type.equals("Object")) {
				attribute = "$" + attribute + "$";

				linkvalue = "$";
				for (int k = 0; k < configs.getAttributes().get(i)
						.getPrimaryKey().size(); k++) {
					linkValue = columnsMap.get(configs.getAttributes().get(i)
							.getPrimaryKey().get(k));
					if (linkValue != null && !linkValue.isEmpty())
						linkvalue += linkValue + "$";

				}

				cayleymultipleprimarykeyQuery = QUERYDBLQUOTE + dbleqt + id
						+ dbleqt + QUERYDBLQUOTE2 + relation + QUERYDBLQUOTE2
						+ linkvalue + QUERYDBLQUOTEWITHN;
				cayleyQuery.add(cayleymultipleprimarykeyQuery);
				
				CayleyApiConnector.insertIntoDB(id,relation,linkvalue);
				
			} else

				cayleyrelationQuery3 = QUERYDBLQUOTE + dbleqt + id + dbleqt
						+ QUERYDBLQUOTE2 + relation + QUERYDBLQUOTE2
						+ attribute + QUERYDBLQUOTEWITHN;
			
			//add cayleyrelationQuery3 to list here
			
			CayleyApiConnector.insertIntoDB(id,relation,attribute);

			if (attribute != null && !attribute.isEmpty()) {

				// attribute = "$"+attribute+"$";

				cayleyGroupableQuery = QUERYDBLQUOTE + dbleqt + key + dbleqt
						+ QUERYDBLQUOTE2 + QUERYGROUPABLE + QUERYDBLQUOTE2
						+ isGroupable + QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(key,QUERYGROUPABLE,isGroupable);
				
				cayleyOfTypeQuery2 = QUERYDBLQUOTE + dbleqt + key + dbleqt
						+ QUERYDBLQUOTE2 + QUERYOFTYPE + QUERYDBLQUOTE2 + type
						+ QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(key,QUERYOFTYPE,type);
				
				cayleyNlpQuery = QUERYDBLQUOTE + dbleqt + attribute + dbleqt
						+ QUERYDBLQUOTE2 + QUERYNLP + QUERYDBLQUOTE2 + nlpFeed
						+ QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(attribute,QUERYNLP,nlpFeed);
				
				cayleyNlpQuery2 = QUERYDBLQUOTE + dbleqt + key + dbleqt
						+ QUERYDBLQUOTE2 + QUERYNLP + QUERYDBLQUOTE2 + nlpFeed
						+ QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(key,QUERYNLP,nlpFeed);
				
				cayleyRelationQuery = QUERYDBLQUOTE + dbleqt + relation
						+ dbleqt + QUERYDBLQUOTE2 + QUERYSMALLRELATION
						+ QUERYDBLQUOTE2 + key + QUERYDBLQUOTEWITHN;

				CayleyApiConnector.insertIntoDB(relation,QUERYSMALLRELATION,key);
				
				cayleyIsAAttributeQuery1 = QUERYDBLQUOTE + dbleqt + attribute
						+ dbleqt + QUERYDBLQUOTE2 + QUERYISA + QUERYDBLQUOTE2
						+ key + QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(attribute,QUERYISA,key);
				
				cayleyOfTypeQuery3 = QUERYDBLQUOTE + dbleqt + relation + dbleqt
						+ QUERYDBLQUOTE2 + QUERYOFTYPE + QUERYDBLQUOTE2
						+ QUERYCAPSRELATION + QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(relation,QUERYOFTYPE,QUERYCAPSRELATION);

				cayleyrelationQuery = QUERYDBLQUOTE + dbleqt + attributekey
						+ dbleqt + QUERYDBLQUOTE2 + QUERYSMALLRELATION
						+ QUERYDBLQUOTE2 + relation + QUERYDBLQUOTEWITHN;
				
				CayleyApiConnector.insertIntoDB(attributekey,QUERYSMALLRELATION,relation);
				
				if (type.equals("Object")) {
					cayleyaliasquery = QUERYDBLQUOTE + dbleqt + relation
							+ dbleqt + QUERYDBLQUOTE2 + QUERYALIAS
							+ QUERYDBLQUOTE2 + aliasform + QUERYDBLQUOTEWITHN;
					
					CayleyApiConnector.insertIntoDB(relation,QUERYALIAS,aliasform);
					
				}

				else {
					cayleydatatypeQuery = QUERYDBLQUOTE + dbleqt + key + dbleqt
							+ QUERYDBLQUOTE2 + QUERYDATATYPE + QUERYDBLQUOTE2
							+ datatype + QUERYDBLQUOTEWITHN;
					
					CayleyApiConnector.insertIntoDB(key,QUERYDATATYPE,datatype);
					
				}

				cayleyQuery.add(cayleyrelationQuery);
				cayleyQuery.add(cayleyNlpQuery);
				cayleyQuery.add(cayleyGroupableQuery);
				cayleyQuery.add(cayleyRelationQuery);
				cayleyQuery.add(cayleyOfTypeQuery2);
				cayleyQuery.add(cayleyOfTypeQuery3);
				cayleyQuery.add(cayleyOfTypeQuery4);
				cayleyQuery.add(cayleyIsAAttributeQuery1);
				cayleyQuery.add(cayleyrelationQuery3);
				cayleyQuery.add(cayleyNlpQuery2);
				cayleyQuery.add(cayleydatatypeQuery);
				cayleyQuery.add(cayleyaliasquery);

			}
			/*
			 * System.out.println("json arrayyyy isssss"+jsonArray+"size"+jsonArray
			 * .length());
			 * 
			 * JSONConnection obj = new JSONConnection(); try {
			 * obj.executeArray(new StringEntity(jsonArray.toString())); } catch
			 * (IOException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); } System.out .println("i value is :"+i);
			 */
		}

	}
	
}
