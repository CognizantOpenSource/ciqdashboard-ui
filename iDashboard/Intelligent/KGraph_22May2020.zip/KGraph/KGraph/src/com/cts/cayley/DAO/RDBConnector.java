package com.cts.cayley.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.primefaces.json.JSONException;

import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphTableVO;
import com.cts.cayley.process.CayleyConverter;

public class RDBConnector extends Connector {

	
                private static Statement createConnection(String dbName, String username, String password, String host, String connectionStr)
                {
                
                                try {
                            String url = "jdbc:mysql://"+host+"/"+dbName;
                            Class.forName(connectionStr);
                            Connection con = DriverManager.getConnection(url,username,password);
                            return con.createStatement();
                        } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                                return null;            
                }
                
                public void getData(GraphDBVO configs,GraphTableVO tableVO) {     
                                
                	 
                                Statement stmt = null;
                                ResultSet rs = null;
                                Set<String> keys = null;
                                HashMap<String,String> columnsMap = null;
                                Set<String> cayleyQuery = new HashSet<String>();
                                try
                                {

                                           
                                          
                                                	
                                
                                

                                     stmt = RDBConnector.createConnection(tableVO.getDbName(), configs.getUsername(), configs.getPassword(), configs.getHost(), "org.mariadb.jdbc.Driver");
                                     rs = stmt.executeQuery(tableVO.getQuery()); // executing query.
                                     columnsMap = new HashMap<String, String>(); 
                                     while(rs.next()) { 
                                        CayleyApiConnector.readCount++;
                                         // System.out.println("CayleyConverter.varCount  "+CayleyConverter.varCount);
                                         // System.out.println("JSONConnection1.readCount   "+JSONConnection1.readCount);
                                        if (CayleyApiConnector.readCount<CayleyConverter.varCount)
                                        continue;
                                        for(int i=0;i<tableVO.getConfig().getAttributes().size();i++)
                                        {
                                          columnsMap.put(tableVO.getConfig().getAttributes().get(i).getDbColumnName(),rs.getString(tableVO.getConfig().getAttributes().get(i).getDbColumnName()));    
                                        }
                                        try {
											formQuery(tableVO.getConfig(), columnsMap);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
                                     }  	
                                     Mongo.writeCount(-1);      
                                }

                                catch (SQLException e) {
                                    e.printStackTrace();
                                }
                                finally
                                {
                                    try {
                                            rs.close();
                                    } catch (SQLException e) {
                                           e.printStackTrace();
                                    }
                                }
								                             

                              
                
                }


}
