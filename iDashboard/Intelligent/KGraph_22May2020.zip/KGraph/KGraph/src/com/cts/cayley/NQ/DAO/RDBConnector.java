package com.cts.cayley.NQ.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.primefaces.json.JSONException;

import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphTableVO;

public class RDBConnector extends Connector {
	
		static HashMap<String,String> columnsMap = null;

       private static Statement createConnection(String dbName, String username, String password, String host, String connectionStr)
       {
                
                          try {
                            String url = "jdbc:mysql://"+host+"/"+dbName;
                            Class.forName(connectionStr);
                            Connection con = DriverManager.getConnection(url,username,password);
                            return con.createStatement();
                          } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                          } catch (SQLException e) {
                            // TODO Auto-generated catch block
                          e.printStackTrace();
                          }
                          return null;            
       }
                
       public Set<String> getData(GraphDBVO configs,GraphTableVO tableVO) {     
                                
            	   		    
            	   		Statement stmt = null;
            	   		ResultSet rs = null;
            	   		Set<String> cayleyQuery = new HashSet<String>();
            	   		
            	   		try {
            	   			stmt = RDBConnector.createConnection(tableVO.getDbName(), configs.getUsername(), configs.getPassword(), configs.getHost(), "org.mariadb.jdbc.Driver");
            	   			rs = stmt.executeQuery(tableVO.getQuery()); // executing query.
            	   			columnsMap = new HashMap<String, String>(); 
            	   			
            	   			while(rs.next()) {
            	   				
            	   				
            	   					for(int i=0;i<tableVO.getConfig().getAttributes().size();i++) {
            	   						columnsMap.put(tableVO.getConfig().getAttributes().get(i).getDbColumnName(),rs.getString(tableVO.getConfig().getAttributes().get(i).getDbColumnName()));
            	   					}
            	   				
            	   				
            	   				try {
            	   					cayleyQuery.addAll(formQuery(tableVO.getConfig(), columnsMap));
            	   				} catch (JSONException e) {
            	   					// TODO Auto-generated catch block
            	   					e.printStackTrace();
            	   				}
            	   			}  	
            	   		  }
            	   		 catch (SQLException e) {
            	   				e.printStackTrace();   }
            	   			finally  {
            	   				try {
            	   					rs.close();
            	   				} catch (SQLException e) {
            	   					e.printStackTrace();
            	   				}
            	   			}                              
            	   			try {
            	   				stmt.close();
            	   			
							} catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				return cayleyQuery;
        }
   
    
         
                   
       			
}
