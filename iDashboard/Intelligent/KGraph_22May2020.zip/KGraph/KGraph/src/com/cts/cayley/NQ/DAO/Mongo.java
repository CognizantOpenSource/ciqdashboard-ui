package com.cts.cayley.NQ.DAO;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphTableVO;
import com.cts.cayley.exception.BaseException;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.util.JSON;

 
public class Mongo extends Connector  {
                               
	public static int totalRecords = 0 ;
    private static final int LIMIT = 50000;
	private final String LOOKUP_AS = "field";
	private static MongoClient mongoClient;
    private static MongoDatabase db ;    
	Set<String> cayleyQuery = new HashSet<String>();
	static HashMap<String,String> columnsMap = new HashMap<String,String>();
	
	private static MongoDatabase createConnection(GraphDBVO configs,GraphTableVO configTable) throws UnknownHostException  {   
    			
    				if(db == null){
    					System.out.println("here in creating connections...");
						// Now connect to your databases
    					if(mongoClient == null)
						mongoClient = new MongoClient( configs.getHost(),configs.getPort());
						db = mongoClient.getDatabase(configTable.getDbName());
						//boolean auth = db..authenticate(configs.getUsername(), configs.getPassword().toCharArray());
					}
					return db;
	}
	
	public Set<String> getData(GraphDBVO configs,GraphTableVO configTable) {                                               
				
    			if(configs == null){                                                                               
					configs = new GraphDBVO();
					configs.setHost(configs.getHost());
					configs.setPort(configs.getPort());
					configs.setDbName(configs.getDbName());
					configs.setUsername(configs.getUsername());
					configs.setPassword(configs.getPassword());
				}
				try {
					MongoDatabase db = Mongo.createConnection(configs,configTable);
				} catch (UnknownHostException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
			   }
				if(configTable.getCollectionquery().size()==1) {
                     try {
                    	 try {
								columnsMap =getNormalData(cayleyQuery,configs,configTable);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (BaseException e) {
								// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else{
							try {
								try {
									columnsMap =getdatajoin(cayleyQuery,configs,configTable);
								} catch (BaseException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
			return cayleyQuery;
	}
	
    private HashMap<String,String> getNormalData(Set<String> cayleyQuery, GraphDBVO configs,GraphTableVO configTable) throws JSONException, BaseException, IOException {      
    	
    	 		HashMap<String,String> columnsMap = new HashMap<String,String>();
    	 		ArrayList<String> collectionName=new ArrayList<String>();
    	 		for(int i=0;i<configTable.getCollectionquery().size();i++) {
    	 			collectionName=configTable.getCollectionquery();
    	 			MongoCollection<org.bson.Document> collection = db.getCollection(configTable.getCollectionquery().get(0));
    	 			MongoCursor<org.bson.Document> cursor = collection.find().iterator();
    	 			
    	 		try {
    	     		while (cursor.hasNext()) {
    	     			JSONObject jsonValues = null;
    	     			jsonValues = new JSONObject(JSON.serialize(cursor.next()));
    	     			columnsMap = new HashMap<String, String>();
    	     			Iterator<?> keysValue = jsonValues.keys();
    	     			
					while(keysValue.hasNext()){
						String key = (String)keysValue.next();
						String value = null;
						value = jsonValues.getString(key);
						columnsMap.put(key, value);
							if(jsonValues.isNull(key))
								columnsMap.put(key, null); 
						
						
					}
					cayleyQuery.addAll(formQuery(configTable.getConfig(), columnsMap));
					}
    	 		} finally {
    	        cursor.close();
    	 		}  
    	 		}
    	 		return columnsMap;
	}
  
 
  
    private HashMap<String,String> getdatajoin(Set<String> cayleyQuery, GraphDBVO configs,GraphTableVO configTable) throws JSONException, BaseException, IOException   {
					
					HashMap<String,String> columnsMap = new HashMap<String,String>();
					DBObject lookup = new BasicDBObject();
                    DBObject project = new BasicDBObject();
                    List<DBObject> unwindList = new ArrayList<DBObject>();
                    List<DBObject> pipelineObject = new ArrayList<DBObject>();
                    DBObject unwindSizes = null;
                    DBObject projectFields = new BasicDBObject();
                    MongoCollection<org.bson.Document> collection = null;
                    DBObject lookupFields =null;
                    DBObject sort = new BasicDBObject();
                    DBObject dbObj = new BasicDBObject();
                    DBObject groupField = new BasicDBObject("_id","$_id");
                    DBObject group = new BasicDBObject();
                    ArrayList<String> collectionName=new ArrayList<String>();
                    collection=getDb().getCollection(configTable.getCollectionquery().get(0));
                    collectionName=configTable.getCollectionquery();
				
                    lookupFields = new BasicDBObject("from",configTable.getCollectionquery().get(1));
                    lookupFields.put("localField", configTable.getConfig().getFields().get(0).get(0));
                    lookupFields.put("foreignField", configTable.getConfig().getFields().get(1).get(0));
                    lookupFields.put("as", LOOKUP_AS);
                    
                    lookup = new BasicDBObject("$lookup", lookupFields);
                    List<String> localFields = configTable.getConfig().getFields().get(0);
                    for(int n=0;n<localFields.size();n++) {
                    	projectFields.put(localFields.get(n), 1);
                    	groupField.put(localFields.get(n), "$"+localFields.get(n));  //group field
                    }
                    
                    List<String> foreignFields = configTable.getConfig().getFields().get(1);
                    for(int n=1;n<foreignFields.size();n++) {
                    	projectFields.put(foreignFields.get(n), "$"+LOOKUP_AS+"."+foreignFields.get(n));
                    	groupField.put(foreignFields.get(n), "$"+foreignFields.get(n));  //group field
                    	unwindSizes = new BasicDBObject("$unwind","$"+foreignFields.get(n));
                    	unwindList.add(unwindSizes);
                    	
                    }
                    project = new BasicDBObject("$project", projectFields);
                    group = new BasicDBObject("$group",new BasicDBObject("_id",groupField));
                     
                       
                    AggregateIterable<org.bson.Document> output;
                    int iteration = 0;
                    do
                    {
                    	pipelineObject = new ArrayList<DBObject>();
                    
                    pipelineObject.add(lookup);
                    pipelineObject.add(project);
                    pipelineObject.addAll(unwindList);
                    pipelineObject.add(group);
                    
                    dbObj = new BasicDBObject("_id",1);
                    sort = new BasicDBObject("$sort",dbObj);
                    pipelineObject.add(sort);
                    
                    
                    dbObj = new BasicDBObject("$skip",LIMIT*iteration);                
                    pipelineObject.add(dbObj);
                    dbObj = new BasicDBObject("$limit",LIMIT);
                    pipelineObject.add(dbObj);
                    
                    
                    List<? extends Bson> pipeline = (List<? extends Bson>) pipelineObject;

                     output = collection.aggregate(pipeline).allowDiskUse(true);
					 JSONObject jsonValues = null;
					 JSONArray array = new JSONArray(JSON.serialize(output));
					 totalRecords += array.length();
					 for(int i=0;i<array.length();i++)
					 {
						 jsonValues = array.getJSONObject(i).getJSONObject("_id");
						 Iterator<?> keysValue = jsonValues.keys();
						 columnsMap = new HashMap<String,String>();
						  while(keysValue.hasNext()){
							String key = (String)keysValue.next();
							if(!key.equalsIgnoreCase("_id"))
							{
								String value = null;
								value = jsonValues.getString(key);
								
								 columnsMap.put(key, value); 
								 if(jsonValues.isNull(key))
								 columnsMap.put(key, null); 
							
								
							} 
						 }
							cayleyQuery.addAll(formQuery(configTable.getConfig(), columnsMap));  
					} 
					System.out.println("iterations done!");
					iteration++;
                    }while(output.first() != null);
					 System.out.println("##iteration "+iteration);
					return columnsMap;
	}
    public static MongoClient getMongoClient() {
		if(mongoClient == null){
			mongoClient = new MongoClient( "localhost" , 27017 ); 
		}
	return mongoClient;
    }
    public MongoDatabase getDb() throws UnknownHostException {
		return db;
    }
   
	
}
	   