package com.cts.cayley.DAO;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;


public class CayleyApiConnector 
{
	//StringEntity entity= new StringEntity(JsonArray.toString());

	//private HttpClient httpClient = HttpClients.createDefault();
	//static HttpPost req = null;
	public static int cnt = 0;
	public static int readCount;
	
	public static void insertIntoDB(String fromNode, String relation, String toNode)
	{
		JSONArray jsonArray = new JSONArray();
		JSONObject json = new JSONObject();
		try {
			json.put("subject", fromNode);
			json.put("predicate", relation);
			json.put("object", toNode);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		jsonArray.put(json);
		try {
			write(new StringEntity(jsonArray.toString()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static String write(StringEntity jsonArr)
	{
		
		System.out.println(cnt);
		int ii=0;

		System.out.println("executedAarray:::"+ii++);
		HttpClient httpClient = HttpClients.createDefault();
		String api="api/v1/write";
		HttpPost req = new HttpPost("http://10.219.161.191:64210/"+api);

		System.out.println("executedAarray:::"+ii++ );
		//String api="/api/v1/write";
		req = new HttpPost("http://10.219.161.175:64210/"+api);

		
		req.addHeader("content-type", "application/json");
		req.setEntity(jsonArr);
		HttpResponse resp = null;
	    try{
		resp = httpClient.execute(req);

		//System.out.println("apiiiiiiiiiii"+api);

		} catch (IOException e) {
			
			
			Mongo.writeCount(readCount);
			System.out.println("Record written in db: "+readCount);
			System.exit(1);
			
			e.printStackTrace();
			

		}
		String output="";
		
		if(resp.getStatusLine().getStatusCode()==200)
		{
			//System.out.println("status code"+resp.getStatusLine().getStatusCode());
			BufferedReader br = null;
			try {
				br = new BufferedReader(new InputStreamReader((resp.getEntity().getContent())));
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String temp="";
			System.out.println("Output from Server .... \n");
			try {
				while ((temp = br.readLine()) != null) {
					output+=temp;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		System.out.println("output$$$$$$$$$$$$"+output);

		
	
		return output;
	}
	
}