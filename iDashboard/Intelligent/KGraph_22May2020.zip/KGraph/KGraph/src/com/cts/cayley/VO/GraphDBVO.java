package com.cts.cayley.VO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GraphDBVO implements Serializable
{	
	private String dbType;
    private String username;
	private String password;
	private String host;	
	private String cayleyDirectory;
	private String cayleyConfig;
	private String cayleyLogfileDirectory;
	private int port;
	private List<GraphTableVO> configTable;
	private String dbName;
	//private String query;
	private String table;
	public String getDbType() {
		return dbType;
	}
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getCayleyDirectory() {
		return cayleyDirectory;
	}
	public void setCayleyDirectory(String cayleyDirectory) {
		this.cayleyDirectory = cayleyDirectory;
	}
	public String getCayleyConfig() {
		return cayleyConfig;
	}
	public void setCayleyConfig(String cayleyConfig) {
		this.cayleyConfig = cayleyConfig;
	}
	public String getCayleyLogfileDirectory() {
		return cayleyLogfileDirectory;
	}
	public void setCayleyLogfileDirectory(String cayleyLogfileDirectory) {
		this.cayleyLogfileDirectory = cayleyLogfileDirectory;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public List<GraphTableVO> getConfigTable() {
		return configTable;
	}
	public void setConfigTable(List<GraphTableVO> configTable) {
		this.configTable = configTable;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}

	
	
}
