package com.cts.cayley.process;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

public class FileIO 
{
	public void writeFile(List<String> content, String path) throws IOException
	{
		BufferedWriter writer = new BufferedWriter( new FileWriter(path));
		for(int i=0;i<content.size();i++)
		{
			writer.write(content.get(i));
		}
				
		writer.close();
	}
	
	public String readFile(String path) throws IOException
	{
		StringBuilder stringBuilder = new StringBuilder();
		InputStream stream = new FileInputStream(path);
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));

		String line;
        while ((line = bufferedReader.readLine()) != null) {
	           stringBuilder.append(line);
	   } 

	   bufferedReader.close();
	   return stringBuilder.toString();
	}
}
