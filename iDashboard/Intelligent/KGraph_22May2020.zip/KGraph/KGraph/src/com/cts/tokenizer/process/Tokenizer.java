package com.cts.tokenizer.process;


import java.util.ArrayList;
import java.util.StringTokenizer;  

public class Tokenizer{  
	public static ArrayList<String> tokenize(String input, String delimiter) {
		ArrayList<String> Tokenizer= new ArrayList<String>();
		//String delimiter=(" '@','-',',' ',''' ");
		StringTokenizer st = new StringTokenizer(input,delimiter);  
		while (st.hasMoreTokens()) {  
			Tokenizer.add(st.nextToken());


		}
		return Tokenizer;
	}

}

