package com.cts.cayley.DAO;
/*
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.swing.text.Document;

import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

//import com.aliasi.util.Arrays;
import com.cts.cayley.VO.GraphDBVO;
import com.cts.cayley.VO.GraphTableVO;
import com.cts.cayley.VO.Kgraphattributemongovo;
import com.cts.cayley.VO.MongoVO;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
//import org.springframework.data.mongodb.core.query.BasicQuery;
import com.mongodb.util.JSON;


public class MongoConnector extends Connector {
	
	private static MongoConnector mongoconnector;
	private static MongoClient mongoClient;
    private static DB db ;
	private static MongoVO mongovo;
	
	
static{
		
		try
        {
            
        	InputStream propertiesInputStream = null;
    		Properties propertyList = null;
        	propertiesInputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("config.properties");
			propertyList = new Properties();
			propertyList.load(propertiesInputStream);
			
            //System.out.println(propertyList);
            mongovo =new MongoVO();

            mongovo.setDbHost(propertyList.getProperty("dbHost"));
            mongovo.setDbPort(Integer.parseInt(propertyList.getProperty("dbPort")));
            mongovo.setDbName(propertyList.getProperty("dbName"));
            mongovo.setDbUser(propertyList.getProperty("dbUser"));
            mongovo.setPassword(propertyList.getProperty("dbPassword"));
            
        
}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


                private static DB createConnection(MongoVO mongovo) throws UnknownHostException
                {
                	if(db == null){
                                MongoClient mongoClient = new MongoClient( mongovo.getDbHost(),mongovo.getDbPort());
                                                
                                // Now connect to your databases
                                db = mongoClient.getDB(mongovo.getDbName());
                                System.out.println("Connect to database successfully");
                                boolean auth = db.authenticate(mongovo.getDbUser(), mongovo.getPassword().toCharArray());
                	}
                                return db;
                }
                
          
                
           public void writeData(String attributekey,List<String> primecolumn) throws UnknownHostException {
               
        	   DBCollection collection = getDb().getCollection("multiplekeys");
        	   BasicDBObject newDocument = new BasicDBObject();
        	   newDocument.append("$set", new BasicDBObject().append(attributekey, primecolumn));
        	   BasicDBObject searchQuery = new BasicDBObject();
        	   collection.update(searchQuery, newDocument);
        	   WriteResult jobj;
        	   jobj=collection.update(searchQuery, newDocument);
        	  
        	
        	   if((Boolean)jobj.getField("updatedExisting")==false ) {
        		 
        		   		JSONObject json = new JSONObject();
        		 
        		   		try {
        		   			json.put(attributekey, primecolumn);
        		   		} catch (JSONException e) {
        		   			// TODO Auto-generated catch block
        		   			e.printStackTrace();
        		   		}
        		
        		   		DBCollection col = getDb().getCollection("multiplekeys");
        		   		DBObject dbObject = (DBObject)  JSON.parse(json.toString());
        		   		col.insert(dbObject);
             
        	   }
           }
                
          public List<String> readData(String object) throws UnknownHostException {
         
                	DBCollection collection = getDb().getCollection("multiplekeys");
                	DBObject dbo = collection.findOne();
                		
                	return (List<String>) dbo.get(object);
              }

			   public static DB getDb() throws UnknownHostException {
				   if(db == null){
				       db=	createConnection(mongovo);
				   }
			       return db;
			   }

			  public static void setDb(DB db) {
				  MongoConnector.db = db;
			   }

			@Override
			public Set<String> getData(GraphDBVO configs,GraphTableVO configTable) {
				// TODO Auto-generated method stub
				return null;
			}
               }

                

*/

public class MongoConnector {
	
}