function getMin(x){  
var min = parseInt(x[0]);
  for(i=1;i<x.length;i++){
    var n=parseInt(x[i]);
    if(min > n)
      min=n;
  }
  return min;
}

function getMinIn(node, property){
	var array= g.V(node).In(property).ToArray()
    return getMin(array)
}

function getMinOut(node, property){
	var array= g.V(node).Out(property).ToArray()
    return getMin(array)
}

function getMax(x){  
var max = parseInt(x[0]);
  for(i=1;i<x.length;i++){
    var n=parseInt(x[i]);
    if(max < n)
      max=n;
  }
  return max;
}

function getMaxIn(node, property){
	var array= g.V(node).In(property).ToArray()
    return getMax(array)
}

function getMaxOut(node, property){
	var array= g.V(node).Out(property).ToArray()
    return getMax(array)
}

function getCount(x){  
    return x.length;
}

function getCountIn(node, property){
	var array= g.V(node).In(property).ToArray()
    return getCount(array)
}

function getCountOut(node, property){
	var array= g.V(node).Out(property).ToArray()
    return getCount(array)
}

function getAverage(x){  
  if(x.length == 0)
    return 0;
  var avg = 0;
  for(i=0;i<x.length;i++){
    var n=parseInt(x[i]);
    if(isNaN(n))
      continue;
    avg+=n;
  }
  return avg/x.length;
}

function getAverageIn(node, property){
	var array= g.V(node).In(property).ToArray()
    return getAverage(array)
}

function getAverageOut(node, property){
	var array= g.V(node).Out(property).ToArray()
    return getAverage(array)
}
