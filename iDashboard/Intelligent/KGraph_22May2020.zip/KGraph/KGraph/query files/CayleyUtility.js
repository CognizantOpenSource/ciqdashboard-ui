function getDeleteData(idArray)
{
	var deleteData = [], tempData =[];
	idArray.forEach(function(id){
		tempData = g.V(id).As("subject").Out([],"predicate").As("object").TagArray();

		tempData.forEach(function(val){
			delete val.id
		});
		deleteData.push.apply(deleteData,tempData);
	});

	g.Emit(deleteData);
}
