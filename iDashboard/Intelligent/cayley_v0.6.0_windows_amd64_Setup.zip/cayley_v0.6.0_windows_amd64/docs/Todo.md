# TODOs

The main source of our TODO list is our [Github Issues](https://github.com/cayleygraph/cayley/issues),
so we are going to try to avoid duplicating them here. 

### Anything marked "TODO" in the code.
Usually something that should be taken care of.
