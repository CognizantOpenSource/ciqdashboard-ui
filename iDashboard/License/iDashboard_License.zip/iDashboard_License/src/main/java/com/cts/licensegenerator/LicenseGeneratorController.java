/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cts.licensegenerator;

import static com.cts.licensegenerator.LicenseGeneratorScreen.licenseGeneratorScreen;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

/**
 *
 * @author 464258
 */
public class LicenseGeneratorController implements Initializable {

    @FXML
    private DatePicker startdate;
    @FXML
    public DatePicker enddate;
    @FXML
    private TextField licenseTo;
    @FXML
    private TextField macID;
    @FXML
    private Button generate;
    @FXML
    private Button cancel;
    @FXML
    public TextArea logTextArea;
    @FXML
    public Label errorMessage;
    @FXML
    public Button browsebutton;
    @FXML
    public TextField filepath;
    @FXML
    public TextArea textarea;
    @FXML
    public ScrollPane versionSelectionArea;
    @FXML
    public Button decrypt;
    @FXML
    public RadioButton licenseTypeInternal;
    @FXML
    public RadioButton licenseTypeClient;
    
   
    static final private String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    final private Random rng = new SecureRandom();
    List<CheckBox[]> tierCBs = new ArrayList<>();
    List<RadioButton[]> tierRBs = new ArrayList<>();
    List<List<String>> allVersionInfo = new ArrayList<>();
    File importedKeyFile;
    String commonEntryPoint = "seventhparameter";

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        macID.setText("xx-xx-xx-xx-xx-xx");
        StringConverter<String> formatter;
        formatter = new StringConverter<String>() {
            @Override
            public String fromString(String string) {
                if (string.length() == 17) {
                    return string;
                } else if (string.length() == 12 && string.indexOf('-') == -1) {
                    return string.substring(0, 2) + "-"
                            + string.substring(2, 4) + "-" + string.substring(4, 6) + "-" + string.substring(6, 8) + "-" + string.substring(8, 10) + "-" + string.substring(10, 12);
                } else {
                    return "xx-xx-xx-xx-xx-xx";
                }
            }

            @Override
            public String toString(String object) {
                System.out.println("toString(): object = " + object);
                if (object == null) // only null when called from 
                {
                    return "xx-xx-xx-xx-xx-xx"; // TextFormatter constructor 
                } 
                return object;
            }
        };
        macID.setTextFormatter(new TextFormatter<String>(formatter, "xx-xx-xx-xx-xx-xx"));
        int numberOfBots = ReadJson.getInstance().findNumberOfTiers();
        startdate.setValue(LocalDate.now());

        final Callback<DatePicker, DateCell> startDayCellFactory
                = new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item.isBefore(
                                startdate.getValue())) {
                            setDisable(true);
                            setStyle("-fx-background-color: #ffc0cb;");
                        }
                    }
                };
            }
        };
        startdate.setDayCellFactory(startDayCellFactory);
        final Callback<DatePicker, DateCell> endDayCellFactory
                = new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item.isBefore(
                                startdate.getValue().plusDays(1))) {
                            setDisable(true);
                            setStyle("-fx-background-color: #ffc0cb;");
                        }
                    }
                };
            }
        };
        enddate.setDayCellFactory(endDayCellFactory);
        VBox scrollPaneVBox = new VBox();
        versionSelectionArea.setContent(scrollPaneVBox);
        versionSelectionArea.setFitToHeight(false);
        ToggleGroup group = new ToggleGroup();

        for (int i = 1; i <= numberOfBots; i++) {
            VBox box = new VBox();
            box.setSpacing(15);
            scrollPaneVBox.getChildren().add(box);
            List<List<String>> botDetails = ReadJson.getInstance().findVersionInEachTier(i);
            allVersionInfo.addAll(botDetails);
            CheckBox[] currentActiveCBs = new CheckBox[botDetails.size()];
            RadioButton[] currentActiveRBs = new RadioButton[botDetails.size()];
            RadioButton selectAllCBs = new RadioButton("Tier " + i + " : " + botDetails.get(1).get(1));
            selectAllCBs.setToggleGroup(group);

            selectAllCBs.setFont(Font.font("System", FontWeight.BOLD, 12));
            box.getChildren().add(selectAllCBs);
            //add listener to link up with function for selectAll
         //   selectAllCBs.setOnAction(this::selectAllCheckBoxes);
            int j = 0;
            for (List bots : botDetails) {
                CheckBox cb = new CheckBox((String) bots.get(2));
                RadioButton rb = new RadioButton((String) bots.get(1));
                currentActiveCBs[j] = cb;
                currentActiveRBs[j] = rb;
                /* TextField tx = new TextField((String) bots.get(1));
                tx.setId((String) bots.get(1));
                tx.focusedProperty().addListener(new ChangeListener<Boolean>() {
                    @Override
                    public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldPropertyValue, Boolean newPropertyValue) {
                        if (!newPropertyValue) {
                            String botName = tx.getId();
                            String botTransactions = tx.getText();
                            for (int i = 0; i < allVersionInfo.size(); i++) {
                                List<String> botDetails = allVersionInfo.get(i);
                                if (botName.equalsIgnoreCase(botDetails.get(1))) {
                                    botDetails.set(2, botTransactions);
                                    allVersionInfo.set(i, botDetails);
                                    break;
                                }
                            }
                        }
                    }
                });*/
                HBox hbox = new HBox();
                final Pane spacer = new Pane();
                HBox.setHgrow(spacer, Priority.ALWAYS);
                spacer.setMinSize(10, 1);
                Double totalLength = hbox.getWidth();
                GridPane g = new GridPane();
                hbox.setSpacing(20);
                hbox.getChildren().addAll(cb, spacer);
                box.getChildren().add(hbox);
                box.setSpacing(5);
                j++;
            }
            Separator s = new Separator();
            box.getChildren().add(s);
            tierCBs.add(currentActiveCBs);
            tierRBs.add(currentActiveRBs);
        }

    }

/*    private void selectAllCheckBoxes(ActionEvent event) {
        CheckBox parentCheckBox = (CheckBox) event.getSource();
        int tierValue = Integer.parseInt(parentCheckBox.getText().substring(5, 6));
        CheckBox[] currentCbs = tierCBs.get(tierValue - 1);
        for (CheckBox cb : currentCbs) {
            if (parentCheckBox.isSelected()) {
                cb.setSelected(true);
            } else {
                cb.setSelected(false);
            }
        }
    }*/

    @FXML
    private void cancelButtonPressed(ActionEvent event) {
        Stage stage = (Stage) macID.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void browseForKey(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select the file to be imported");
        FileChooser.ExtensionFilter extFilter
                = new FileChooser.ExtensionFilter("Key File(*.elf)", "*.elf");
        fileChooser.getExtensionFilters().add(extFilter);
        importedKeyFile = fileChooser.showOpenDialog(licenseGeneratorScreen);
        if (importedKeyFile != null) {
            String binFilePath = importedKeyFile.getAbsolutePath();
            filepath.setText(binFilePath);
        }
    }

    @FXML
    private void readLicense() {
        if (importedKeyFile == null) {
            textarea.appendText("Key File Not Found\n");
            return;
        }
        Task<Void> task;
        task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        readLicenseAfterDecryption(importedKeyFile);
                    }
                });
                return null;
            }
        };
        Thread thread = new Thread(task);
        // thread.setDaemon(true);
        thread.start();
    }

    private void showErrorMessage(String Message) {
        errorMessage.setText(Message);
        errorMessage.setVisible(true);
    }

    private void readLicenseAfterDecryption(File licenseFile) {
        try {
            char stringToken = ';';
            String result = "Invalid License!";
            byte[] bytes = EncryptDecrypt.readSmallBinaryFile(licenseFile.getAbsolutePath());
            String encryptedDeatils = new String(bytes);
            String iv = "RandomInitVector";
            String decyptedString = EncryptDecrypt.decrypt(commonEntryPoint, iv, encryptedDeatils);
            textarea.clear();
            if (!decyptedString.contains("\n")) {
                textarea.appendText("Invalid Key!\n");
                return;
            }
            String[] details = decyptedString.split("\n");
            Date fromDate = null, toDate = null;
            SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");            
            for(String s: details){
                System.out.println("Values : ======= "+s);
            }
            try {
                fromDate = sdf.parse(details[0]);
                toDate = sdf.parse(details[1]);
            } catch (Exception e) {
                e.printStackTrace();
            }
            textarea.appendText("\nLicense From Date : " + fromDate);
            textarea.appendText("\nLicense To Date : " + toDate);
            String user = details[2];
            textarea.appendText("\nLicense Assigned To: " + user);
            String product = details[3];
            textarea.appendText("\nMac ID : " + product);
            String listOfBots = details[4];
            List<List<String>> listOfSelectedBots = listFromStringofList(listOfBots);
            textarea.appendText("\nList of Bots: \n");
            for (List<String> eachBot : listOfSelectedBots) {
                textarea.appendText(eachBot.toString() + "\n");
            }

        } catch (IOException ex) {
            Logger.getLogger(LicenseGeneratorController.class.getName()).log(Level.SEVERE, "Exception in verifying license", ex);
        }
    }

    /**
     * Specific method written to convert a string object obtained from a
     * List<List<String>> back to its original format. Method is not generic and
     * will not work for any other type of String.
     *
     * @param orginalBotDetails
     * @return List<List<String>>
     */
    public List listFromStringofList(String orginalBotDetails) {
        //String[] firstSplit = from.split("]");
        List<List<String>> allBotsInfo = new ArrayList<>();
        while (orginalBotDetails.contains("]")) {
            int listEndIndex = orginalBotDetails.indexOf("]", 0);
            String innerListString = orginalBotDetails.substring(0, listEndIndex).replace("[", "");
            String[] currentBots = innerListString.split(",");
            List<String> currentBotInfo = new ArrayList<>();
            for (int i = 0; i < currentBots.length; i++) {
                currentBotInfo.add(currentBots[i].trim());
            }
            allBotsInfo.add(currentBotInfo);
            orginalBotDetails = orginalBotDetails.substring(listEndIndex + 2, orginalBotDetails.length());
        }
        return allBotsInfo;
    }

    @FXML
    private void generateKey(ActionEvent event) {
        String edition;
        String licenseUser;
        String macID;
        String completeDetail;
        Date startDate = null;
        Date endDate = null;
        RadioButton licenseTypeInternal = null;
        RadioButton licenseTypeClient = null;
        HashMap<String, Integer> listOfBotsAndTransactionsSelected = new HashMap<String, Integer>();
        ArrayList selectedVersionList = new ArrayList<>();
        if (this.startdate.getValue() != null) {
            LocalDate startDateLocal = this.startdate.getValue().minusDays(1);            
            startDate = Date.from(startDateLocal.atStartOfDay(ZoneId.systemDefault()).toInstant());
        } else {
            this.showErrorMessage("Please Enter a Valid Start Date!");
            return;
        }
        if (this.enddate.getValue() != null) {
            LocalDate endDateLocal = this.enddate.getValue().plusDays(1);
            endDate = Date.from(endDateLocal.atStartOfDay(ZoneId.systemDefault()).toInstant());
        } else {
            this.showErrorMessage("Please Enter a Valid End Date!");
            return;
        }
        licenseUser = this.licenseTo.getText();
        macID = this.macID.getText().toLowerCase();
        List<String> selectedversionDeatils = new ArrayList<>();
      /*  boolean rbInternal = this.licenseTypeInternal.isSelected();
        boolean rbClient = this.licenseTypeClient.isSelected();*/
        for (int i = 0; i < tierCBs.size(); i++) {
        	CheckBox[] cbs = tierCBs.get(i);
        	RadioButton[] rbs = tierRBs.get(i);
        	for (RadioButton rb : rbs) {
            for (CheckBox cb : cbs) {
                if (cb.isSelected()) {
                	selectedversionDeatils = getSelectedBotDetailsFromFullList(rb.getText(), cb.getText());
                    if (selectedversionDeatils != null) {
                    	if(!selectedVersionList.contains(selectedversionDeatils)){
                    	selectedVersionList.add(selectedversionDeatils);}
                    }
                }
            }}
        }
        System.out.println("The list of selected checkBoxes are : " + selectedVersionList);
        List<String> licenseDataForExcel = new ArrayList<>();    
        String launchedDateTime = new Date().toString();
        String closedDateTime = new Date().toString();
        String licenseId = randomUUID(12);
        String licenseDetails = startDate.toString()+"\n"+endDate.toString()+"\n"+licenseUser+"\n"+macID+"\n" 
        						+selectedVersionList+"\n"+launchedDateTime+"\n"+closedDateTime+"\n"+licenseId;
        String[] licenseDet = licenseDetails.split("\n");
        licenseDataForExcel = Arrays.asList(licenseDet);
        try {
            licenseDetails = EncryptDecrypt.encrypt(commonEntryPoint, "RandomInitVector", licenseDetails);
            byte[] data = licenseDetails.getBytes();
            FileOutputStream out = new FileOutputStream(".\\pandora.elf");
            createTransactionTracker(selectedVersionList);
            new ExcelManagement().saveLicenseDataIntoExcel(licenseDataForExcel);
            out.write(data);
            out.close();
        } catch (IOException | InvalidFormatException e) {
            e.printStackTrace();
        }
    }

    private void createTransactionTracker(List<List<String>> selectedBotsList) throws IOException{
        String content = "";
        if(selectedBotsList!=null){
            for (List<String> eachBot : selectedBotsList) {
                String botid = eachBot.get(0);
                content = content+botid+"=0\n";              
            }
        }
        
        content = EncryptDecrypt.encrypt(commonEntryPoint, "RandomInitVector", content);
        FileOutputStream out = new FileOutputStream(".\\kerbose.jar");
        byte[] data = content.getBytes();
        out.write(data);
        out = new FileOutputStream(".\\qitsi.jar");
        String qitsi = "AWE4Fe2rj5fjj84bcvzOxjPKYxZBFBDeV1bRDspfj9oVFuAmvYXRjvxII1JPUidZoGLL4hmKrpZsiSj8Ag6toa7CgkOPtomQeY8Rq6Vy8Ao=";
        data = qitsi.getBytes();
        out.write(data);
        out.close();
        
        //Files.write(Paths.get(".\\kerbose.jar"), content.getBytes(), StandardOpenOption.CREATE);
        //Files.write(Paths.get(".\\qitsi.jar"), "".getBytes(), StandardOpenOption.CREATE);        
    }

    /** Private Utility method to search for a particular bot details from within the 
    * master list allBotInfo
    **/
    private List<String> getSelectedBotDetailsFromFullList(String versionName, String toolName) {
        List<String> selectedBotDetails = null;
        for (List<String> botInfo : allVersionInfo) {
        	if(versionName.equals(botInfo.get(1))){
            if (toolName.equals(botInfo.get(2))) {
                selectedBotDetails = botInfo;
            }}
        }
        return selectedBotDetails;
    }
    
    char randomChar() {
        return LicenseGeneratorController.ALPHABET.charAt(this.rng.nextInt(LicenseGeneratorController.ALPHABET.length()));
    }
    
    String randomUUID(int length) {
        StringBuilder sb = new StringBuilder();
        while (length > 0) {
            sb.append(randomChar());
            length--;
        }
        return sb.toString();
    }


}
