/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cts.licensegenerator;

import com.sun.javafx.application.LauncherImpl;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author 464258
 */
public class MainClass {

    @SuppressWarnings("restriction")
	public static void main(String args[]) throws FileNotFoundException, IOException, Exception {
        ReadJson.getInstance().initializeJsonReader();
        LauncherImpl.launchApplication(LicenseGeneratorScreen.class, args);
    }

}
