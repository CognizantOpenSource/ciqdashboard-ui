/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cts.licensegenerator;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author 464258
 */
public class ReadJson {

    JSONParser parser = new JSONParser();
    Object obj = null;
    JSONObject jsonObject = null;
    JSONArray versionInformation = null;

    private static ReadJson jsonReader;

    private ReadJson() {
    }

    /**
     * Create a static method to get instance.
     *
     * @return
     */
    public static ReadJson getInstance() {
        if (jsonReader == null) {
            jsonReader = new ReadJson();
        }
        return jsonReader;
    }

    public void initializeJsonReader() {
        try {
            obj = parser.parse(new FileReader("iDashboardVersionDetails.json"));
            jsonObject = (JSONObject) obj;
            versionInformation = (JSONArray) jsonObject.get("Versions");
        } catch (IOException | ParseException e) {
            System.out.println("Exception in reading the bot details json:\n" + e.getMessage());
        }
    }

    //method to read the total number of versions
    public int findNumberOfTiers() {
        long totalNumberOfTiers = 0;
        totalNumberOfTiers = (long)jsonObject.get("NoOfTiers");
        return (int)totalNumberOfTiers;
    }

    //method to fetch details of versions under each tier
    public List<List<String>> findVersionInEachTier(int tier) {
        List<List<String>> versionDetailsforTier = new ArrayList<>();
        List<String> individualVersionInfo = null;
        Iterator iterator = versionInformation.iterator();
        while (iterator.hasNext()) {
            jsonObject = (JSONObject) iterator.next();
            individualVersionInfo = new ArrayList<>();
            Long tierID = (Long) jsonObject.get("TierID");
            if (tierID.intValue() == tier) {
            	individualVersionInfo.add(jsonObject.get("VersionID").toString());
            	individualVersionInfo.add((String) jsonObject.get("versionName"));
            	individualVersionInfo.add((String) jsonObject.get("Tool"));
                versionDetailsforTier.add(individualVersionInfo);
            }
        }
        return versionDetailsforTier;
    }

}
