/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cts.licensegenerator;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author 464258
 */
public class LicenseDetailsData {

    private final SimpleStringProperty keyColumn;
    private final SimpleStringProperty startdateColumn;
    private final SimpleStringProperty enddateColumn;
    private final SimpleStringProperty userColumn;
    private final SimpleStringProperty productColumn;
    private final SimpleStringProperty selectedVersionColumn;
    private final SimpleStringProperty licenseTypeInternal;
    private final SimpleStringProperty licenseTypeClient;

    public LicenseDetailsData(String keyColumn, String startdateColumn, String enddateColumn, String userColumn, String productColumn, String selectedVersionColumn,
    		String licenseTypeInternal, String licenseTypeClient) {
        this.keyColumn = new SimpleStringProperty(keyColumn);
        this.startdateColumn = new SimpleStringProperty(startdateColumn);
        this.enddateColumn = new SimpleStringProperty(enddateColumn);
        this.userColumn = new SimpleStringProperty(userColumn);
        this.productColumn = new SimpleStringProperty(productColumn);
        this.selectedVersionColumn = new SimpleStringProperty(selectedVersionColumn);
        this.licenseTypeInternal = new SimpleStringProperty(licenseTypeInternal);
        this.licenseTypeClient = new SimpleStringProperty(licenseTypeClient);
    }

    public String getKeyColumn() {
        return keyColumn.get();
    }

    public String getStartdateColumn() {
        return startdateColumn.get();
    }

    public String getEnddateColumn() {
        return enddateColumn.get();
    }

    public String getUserColumn() {
        return userColumn.get();
    }

    public String getProductColumn() {
        return productColumn.get();
    }

    public SimpleStringProperty getSelectedVersionColumn() {
		return selectedVersionColumn;
	}

	public void setKeyColumn(String value) {
        keyColumn.set(value);
    }

    public void setStartdateColumn(String value) {
        startdateColumn.set(value);
    }

    public void setEnddateColumn(String value) {
        enddateColumn.set(value);
    }

    public void setUserColumn(String value) {
        userColumn.set(value);
    }

    public SimpleStringProperty getLicenseTypeInternal() {
		return licenseTypeInternal;
	}

	public SimpleStringProperty getLicenseTypeClient() {
		return licenseTypeClient;
	}

	public void setProductColumn(String value) {
        productColumn.set(value);
    }

   

}
