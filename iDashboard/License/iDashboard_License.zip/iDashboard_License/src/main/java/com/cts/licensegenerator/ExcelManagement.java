/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cts.licensegenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author 464258
 */
public class ExcelManagement {
    Workbook workbook = null;
    String inputFilePath = "IssuedLicenseDetails.xlsx";
    public void saveLicenseDataIntoExcel(List<String> licenseData) throws IOException, InvalidFormatException{
        //read the input file and get all its sheets.
        FileInputStream fis = null;
        try{
        fis = new FileInputStream(new File(inputFilePath));
        
        } catch (FileNotFoundException fe){
            createNewExcelReport();
            fis = new FileInputStream(new File(inputFilePath));
        }
        workbook = WorkbookFactory.create(fis);
        Sheet sheet = workbook.getSheetAt(0);     
        int rowNum = sheet.getLastRowNum();
        Row row = sheet.createRow(++rowNum);
        int columnNum = 0;
        for(String value : licenseData){
            Cell cell = row.createCell(columnNum++);
            cell.setCellValue(value);
        }
        fis.close();
        saveExcel(inputFilePath);
    }
    
    private void createNewExcelReport() throws IOException, InvalidFormatException{
        workbook = new XSSFWorkbook();        
        Sheet sheet = workbook.createSheet();  
        Row header = sheet.createRow(0);
        Font headingFont = workbook.createFont();
        headingFont.setBold(true);
        CellStyle headingStyle = workbook.createCellStyle();
        headingStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        headingStyle.setFont(headingFont);
        header.createCell(0).setCellValue("Start Date");
        header.createCell(1).setCellValue("End Date");
        header.createCell(2).setCellValue("User");
        header.createCell(3).setCellValue("Mac ID");
        header.createCell(4).setCellValue("Selected Version Details");
//        for(int i = 0; i<6; i++){
//        header.getCell(i).setCellStyle(headingStyle);
//        }
        FileOutputStream fileOut = new FileOutputStream(inputFilePath);
        workbook.write(fileOut);
        fileOut.close();
        System.out.println("file Created!");
    }

    public List<List<String>> readTestDataFromExcel(String inputFilePath, String scenarioName) throws IOException, InvalidFormatException{
        List<List<String>> tableData = new ArrayList<>();
        
        workbook = WorkbookFactory.create(new File(inputFilePath));
        Sheet sheet = null;
        for (int i = 0; i < workbook.getNumberOfSheets(); i++)
        {
            Sheet currentSheet = workbook.getSheetAt(i);
            if(currentSheet.getSheetName().equalsIgnoreCase(scenarioName)){
                sheet = currentSheet;
                break;
            }
        }
        if(sheet==null){
            tableData = null;
        } else {
            Iterator<Row> iterator = sheet.iterator();
            int rowCounter = 0;
            while (iterator.hasNext()) {
                 Row currentRow = iterator.next();
                 Iterator<Cell> cellIterator = currentRow.iterator();
                 List<String> columnData = new ArrayList<>();
                 while (cellIterator.hasNext()) {
                      Cell currentCell = cellIterator.next();
                      columnData.add(currentCell.getStringCellValue());
                 }
                 if(rowCounter!=0){
                 tableData.add(columnData);
                 }
                 rowCounter++;
            }
        }
        return tableData;
    }
    
    public void saveExcel(String inputFilePath){
        //Workbook writeWorkbook = Workbook.createWorkbook(inputFilePath,workbook);
        try{
            FileOutputStream outputStream = new FileOutputStream(inputFilePath);            
            workbook.write(outputStream);
            workbook.close();            
        } catch (IOException e){
        } 
    }
    
    
}
